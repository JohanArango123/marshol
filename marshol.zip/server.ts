import express from "express";
import path from "path";
import { GoogleGenAI } from "@google/genai";
import { createServer as createViteServer } from "vite";

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Safe lazy initialization of Gemini API
  const getAIClient = () => {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      console.warn("WARNING: GEMINI_API_KEY environment variable is not defined.");
    }
    return new GoogleGenAI({
      apiKey: apiKey || "MOCK_KEY",
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  };

  // API endpoint for AI wellness coach consultations
  app.post("/api/wellness-chat", async (req, res) => {
    try {
      const { message, history } = req.body;
      if (!message) {
        return res.status(400).json({ error: "El mensaje es obligatorio." });
      }

      if (!process.env.GEMINI_API_KEY) {
        // Fallback for missing API Key to prevent crash
        return res.json({
          text: "¡Hola! Bienvenido a MARSHOL Bienestar. Actualmente estoy en modo de demostración. Me encantaría guiarte sobre tu skincare, bienestar integral y transformación personal. Por favor, asegúrate de configurar tu GEMINI_API_KEY en la sección de secretos para recibir consejos holísticos en tiempo real con inteligencia artificial.\n\nPara empezar: ¿Qué tipo de piel tienes o qué objetivos de bienestar buscas?",
        });
      }

      const ai = getAIClient();
      
      const systemInstruction = `Eres la Coach Holística de MARSHOL, una marca premium de belleza, bienestar integral y transformación personal.
Tus pilares son:
1. Skincare de alta eficacia con enfoque natural y respetuoso.
2. Salud física, nutrición consciente y herbolaria.
3. Transformación personal (salud mental, mindfulness, gestión emocional y rutinas diarias).

Tu tono de comunicación es cálido, empático, sofisticado y sumamente motivacional. Usas un lenguaje poético pero con bases sólidas sobre el cuidado de la piel y el bienestar corporal.
Siempre que te consulten, ofrece respuestas estructuradas que incluyan:
- Un mensaje de aliento y sintonía emocional.
- Un paso práctico de Skincare de MARSHOL (por ejemplo, hablar de tónicos, sérums, limpiezas dobles, hidratación profunda).
- Una recomendación de Salud/Nutrición (infusiones, adaptógenos, alimentación consciente).
- Un ritual de Transformación (ejercicios de respiración, journaling, afirmaciones de autoestima).

Mantén tus respuestas relativamente concisas, estructuradas y en un español impecable con toques de calidez (puedes usar el emoji 💜 para representar a la marca).`;

      // Formulate contents with history
      const formattedContents = [];
      if (history && Array.isArray(history)) {
        for (const turn of history) {
          formattedContents.push({
            role: turn.role === "user" ? "user" : "model",
            parts: [{ text: turn.text }],
          });
        }
      }
      formattedContents.push({
        role: "user",
        parts: [{ text: message }],
      });

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: formattedContents,
        config: {
          systemInstruction,
          temperature: 0.7,
        },
      });

      res.json({ text: response.text });
    } catch (error: any) {
      console.error("Error in /api/wellness-chat:", error);
      res.status(500).json({
        error: "Hubo un problema al procesar tu consulta de bienestar. Por favor intenta de nuevo.",
        details: error.message,
      });
    }
  });

  // API endpoint for holistic quiz diagnosis
  app.post("/api/wellness-diagnosis", async (req, res) => {
    try {
      const { answers } = req.body;
      if (!answers) {
        return res.status(400).json({ error: "Las respuestas del diagnóstico son obligatorias." });
      }

      const { skinType, mainConcern, stressLevel, physicalEnergy, sleepQuality, transformationGoal } = answers;

      if (!process.env.GEMINI_API_KEY) {
        return res.json({
          report: `### 💜 Tu Diagnóstico de Bienestar MARSHOL (Demostración)

¡Gracias por completar tu diagnóstico integral! Aquí tienes un avance de tu perfil:

*   **Tipo de Piel:** ${skinType || "No especificado"}
*   **Preocupación Principal:** ${mainConcern || "No especificado"}
*   **Nivel de Estrés:** ${stressLevel || "Moderado"}
*   **Energía Física:** ${physicalEnergy || "Regular"}
*   **Calidad de Sueño:** ${sleepQuality || "Regular"}
*   **Meta de Transformación:** ${transformationGoal || "Bienestar General"}

#### 🌸 Ritual Diario Sugerido:
1.  **Mañana:** Limpieza suave + Tónico de lavanda + Sérum antioxidante protector.
2.  **Tarde:** Hidratación constante y pausas de respiración consciente (3 minutos).
3.  **Noche:** Doble limpieza + Crema revitalizante regeneradora + Journaling de gratitud.

*(Nota: Configura tu API Key de Gemini en el panel de secretos de AI Studio para recibir un análisis holístico ultra-personalizado y profundo generado por nuestra Inteligencia Artificial).*`,
        });
      }

      const ai = getAIClient();

      const prompt = `Analiza los siguientes datos de un cliente de MARSHOL que busca una transformación integral de belleza, salud y bienestar, y redacta un plan de diagnóstico holístico, motivador y estructurado:

- Tipo de Piel: ${skinType}
- Preocupación de la Piel: ${mainConcern}
- Nivel de Estrés Diario: ${stressLevel}
- Energía Física: ${physicalEnergy}
- Calidad del Sueño: ${sleepQuality}
- Meta de Transformación Integral: ${transformationGoal}

Escribe tu respuesta en un formato Markdown hermoso, organizado con títulos elegantes y emojis. El diagnóstico debe incluir:
1. **Análisis de Sinergia (El Espejo de tu Interior):** Cómo se conecta su nivel de estrés y sueño con el estado actual de su piel y su energía física.
2. **Tu Ritual de Skincare MARSHOL Personalizado:** Una rutina detallada paso a paso (mañana y noche) enfocada en sus preocupaciones.
3. **Tu Receta de Bienestar Integral (Salud y Energía):** Recomendaciones de alimentación, suplementación herbolaria, tés/infusiones o adaptógenos recomendados para potenciar su energía y calmar su sistema nervioso.
4. **Práctica de Transformación de Mentalidad (Mindfulness y Hábitos):** Un ejercicio de 5 minutos diario adaptado a su meta de transformación (ej. meditación guiada, journaling, respiración pranayama).
5. **Afirmación Semanal de Poder:** Una frase poderosa de transformación para repetir cada mañana.

Usa un tono sofisticado, cariñoso y profundamente transformador. Refiérete a la marca MARSHOL y sus pilares de belleza, salud y bienestar integral.`;

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt,
        config: {
          temperature: 0.7,
        },
      });

      res.json({ report: response.text });
    } catch (error: any) {
      console.error("Error in /api/wellness-diagnosis:", error);
      res.status(500).json({
        error: "Hubo un error al generar tu diagnóstico de transformación.",
        details: error.message,
      });
    }
  });

  // Vite middleware setup for development, static serve for production
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[MARSHOL Server] Running on http://localhost:${PORT} with NODE_ENV=${process.env.NODE_ENV}`);
  });
}

startServer();
