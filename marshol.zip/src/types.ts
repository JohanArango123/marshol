export interface Product {
  id: string;
  name: string;
  category: "skincare" | "salud" | "cuidado_personal";
  price: number;
  rating: number;
  description: string;
  fullDescription: string;
  benefits: string[];
  ingredients: string[];
  ritual: string;
  image: string;
  tag?: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface QuizAnswers {
  skinType: string;
  mainConcern: string;
  stressLevel: string;
  physicalEnergy: string;
  sleepQuality: string;
  transformationGoal: string;
}

export interface ChatMessage {
  id: string;
  role: "user" | "model";
  text: string;
  timestamp: Date;
}

export interface Habit {
  id: string;
  name: string;
  category: "skincare" | "salud" | "transformacion";
  timeOfDay: "mañana" | "noche";
  completed: boolean;
  streak: number;
  points: number;
  description: string;
}

export interface Testimonial {
  id: string;
  name: string;
  age: number;
  location: string;
  text: string;
  rating: number;
  productUsed: string;
  image: string;
}
