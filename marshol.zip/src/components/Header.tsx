import { useState } from "react";
import { ShoppingBag, Sparkles, Brain, ClipboardCheck, Compass, Menu, X, Gift } from "lucide-react";
import { CartItem } from "../types";

interface HeaderProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  cart: CartItem[];
  setCartOpen: (open: boolean) => void;
  openQuiz: () => void;
}

export default function Header({
  activeTab,
  setActiveTab,
  cart,
  setCartOpen,
  openQuiz,
}: HeaderProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const cartCount = cart.reduce((acc, item) => acc + item.quantity, 0);

  const navItems = [
    { id: "home", label: "Inicio", icon: Compass },
    { id: "boutique", label: "Boutique", icon: ShoppingBag },
    { id: "tracker", label: "Ritual Diario", icon: ClipboardCheck },
    { id: "coach", label: "Consultor AI", icon: Brain },
  ];

  return (
    <header className="sticky top-0 z-40 w-full border-b border-purple-100/50 bg-white/95 backdrop-blur-md">
      <div className="mx-auto flex h-20 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        {/* Logo and Brand */}
        <div 
          onClick={() => setActiveTab("home")} 
          className="flex cursor-pointer items-center space-x-3 transition-opacity hover:opacity-90"
          id="brand-logo-container"
        >
          {/* Custom SVG Monogram reproducing the handdrawn interlinked M and S from the logo */}
          <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-purple-700 shadow-md shadow-purple-200">
            <svg
              viewBox="0 0 100 100"
              className="h-8 w-8 fill-none stroke-white stroke-[6] stroke-linecap-round stroke-linejoin-round"
            >
              {/* Monogram MS drawn with beautiful elegant lines */}
              <path d="M 20 75 L 35 25 L 50 60 L 65 25 L 80 75" />
              <path d="M 30 35 C 50 15, 70 30, 50 50 C 30 70, 50 85, 75 70" />
            </svg>
          </div>
          <div>
            <span className="font-serif text-2xl font-bold tracking-[0.2em] text-purple-950">
              MARSHOL
            </span>
            <span className="block text-[9px] font-medium uppercase tracking-[0.15em] text-purple-600">
              Belleza & Bienestar Integral
            </span>
          </div>
        </div>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-1 lg:space-x-4">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                id={`nav-item-${item.id}`}
                onClick={() => {
                  setActiveTab(item.id);
                  setMobileMenuOpen(false);
                }}
                className={`group flex items-center space-x-1.5 rounded-full px-4 py-2 text-sm font-medium transition-all duration-300 ${
                  isActive
                    ? "bg-purple-50 text-purple-800"
                    : "text-gray-600 hover:bg-gray-50 hover:text-purple-700"
                }`}
              >
                <Icon className={`h-4 w-4 transition-transform group-hover:scale-110 ${isActive ? "text-purple-700" : "text-gray-400 group-hover:text-purple-600"}`} />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Right Actions */}
        <div className="flex items-center space-x-3">
          {/* AI Diagnostic CTA */}
          <button
            id="diagnostic-header-btn"
            onClick={openQuiz}
            className="hidden sm:flex items-center space-x-1.5 rounded-full bg-gradient-to-r from-purple-700 to-indigo-700 px-4 py-2 text-xs font-semibold tracking-wide text-white shadow-md shadow-purple-200 transition-all duration-300 hover:from-purple-800 hover:to-indigo-800 hover:shadow-lg active:scale-95"
          >
            <Sparkles className="h-3.5 w-3.5 animate-pulse" />
            <span>Diagnóstico Gratis</span>
          </button>

          {/* Cart Icon */}
          <button
            id="cart-toggle-btn"
            onClick={() => setCartOpen(true)}
            className="relative flex h-10 w-10 items-center justify-center rounded-full bg-purple-50 text-purple-800 transition-all duration-300 hover:bg-purple-100 hover:scale-105 active:scale-95"
          >
            <ShoppingBag className="h-5 w-5 text-purple-700" />
            {cartCount > 0 && (
              <span 
                id="cart-badge-count"
                className="absolute -top-1 -right-1 flex h-5 w-5 items-center justify-center rounded-full bg-purple-600 text-[10px] font-bold text-white ring-2 ring-white animate-bounce"
              >
                {cartCount}
              </span>
            )}
          </button>

          {/* Mobile Menu Toggle */}
          <button
            id="mobile-menu-toggle"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="flex h-10 w-10 items-center justify-center rounded-full text-gray-600 transition-colors hover:bg-gray-100 md:hidden"
          >
            {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu Panel */}
      {mobileMenuOpen && (
        <div className="border-t border-purple-50 bg-white px-4 pt-2 pb-6 shadow-xl md:hidden animate-in slide-in-from-top duration-300">
          <div className="space-y-2">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  id={`mobile-nav-item-${item.id}`}
                  onClick={() => {
                    setActiveTab(item.id);
                    setMobileMenuOpen(false);
                  }}
                  className={`flex w-full items-center space-x-3 rounded-xl px-4 py-3 text-base font-medium transition-all ${
                    isActive
                      ? "bg-purple-50 text-purple-800"
                      : "text-gray-600 hover:bg-gray-50 hover:text-purple-700"
                  }`}
                >
                  <Icon className={`h-5 w-5 ${isActive ? "text-purple-700" : "text-gray-400"}`} />
                  <span>{item.label}</span>
                </button>
              );
            })}
            <div className="pt-4 border-t border-purple-50">
              <button
                id="mobile-diagnostic-btn"
                onClick={() => {
                  openQuiz();
                  setMobileMenuOpen(false);
                }}
                className="flex w-full items-center justify-center space-x-2 rounded-xl bg-gradient-to-r from-purple-700 to-indigo-700 py-3 text-sm font-semibold text-white shadow-md shadow-purple-100"
              >
                <Sparkles className="h-4 w-4 animate-pulse" />
                <span>Iniciar Diagnóstico Gratis</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
