import { useState } from "react";
import { Search, Star, Info, ShoppingCart, SlidersHorizontal, Check, ArrowRight } from "lucide-react";
import { Product } from "../types";
import { PRODUCTS } from "../data";

interface BoutiqueProps {
  onAddToCart: (product: Product) => void;
  onOpenCoachWithProduct: (productName: string) => void;
}

export default function Boutique({ onAddToCart, onOpenCoachWithProduct }: BoutiqueProps) {
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [sortBy, setSortBy] = useState<string>("featured");
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [addedProductId, setAddedProductId] = useState<string | null>(null);

  const categories = [
    { id: "all", label: "Todos", icon: "✨" },
    { id: "skincare", label: "Skincare", icon: "🌸" },
    { id: "salud", label: "Salud & Bienestar", icon: "🌿" },
    { id: "cuidado_personal", label: "Cuidado Personal", icon: "💜" },
  ];

  // Filtering & Sorting Logic
  const filteredProducts = PRODUCTS.filter((product) => {
    const matchesCategory = selectedCategory === "all" || product.category === selectedCategory;
    const matchesSearch =
      product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.ingredients.some((ing) => ing.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesCategory && matchesSearch;
  }).sort((a, b) => {
    if (sortBy === "price-low") return a.price - b.price;
    if (sortBy === "price-high") return b.price - a.price;
    if (sortBy === "rating") return b.rating - a.rating;
    return 0; // Featured / Default
  });

  const handleAddToCart = (product: Product) => {
    onAddToCart(product);
    setAddedProductId(product.id);
    setTimeout(() => setAddedProductId(null), 2000);
  };

  return (
    <section className="py-16 bg-white" id="boutique-section">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        
        {/* Header Section */}
        <div className="text-center max-w-2xl mx-auto mb-12">
          <h2 className="font-serif text-3xl font-extrabold tracking-tight text-purple-950 sm:text-4xl">
            Nuestra Boutique Holística
          </h2>
          <div className="h-1 w-20 bg-purple-600 mx-auto my-4 rounded-full"></div>
          <p className="text-gray-600">
            Fórmulas botánicas conscientes elaboradas para nutrir tu piel, fortalecer tu salud física y guiar tu transformación personal desde adentro.
          </p>
        </div>

        {/* Search, Filter & Sort Controls */}
        <div className="flex flex-col gap-6 md:flex-row md:items-center md:justify-between mb-8 pb-6 border-b border-purple-100">
          
          {/* Category Tabs */}
          <div className="flex flex-wrap gap-2 overflow-x-auto pb-2 md:pb-0 scrollbar-none">
            {categories.map((cat) => (
              <button
                key={cat.id}
                id={`cat-filter-${cat.id}`}
                onClick={() => setSelectedCategory(cat.id)}
                className={`flex items-center space-x-1.5 rounded-full px-5 py-2.5 text-sm font-medium transition-all duration-300 ${
                  selectedCategory === cat.id
                    ? "bg-purple-700 text-white shadow-md shadow-purple-100 scale-105"
                    : "bg-purple-50 text-purple-950 hover:bg-purple-100/60"
                }`}
              >
                <span>{cat.icon}</span>
                <span>{cat.label}</span>
              </button>
            ))}
          </div>

          {/* Search and Sort Inputs */}
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1 sm:w-64">
              <input
                type="text"
                id="search-input"
                placeholder="Buscar ingredientes, beneficios..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full rounded-full border border-purple-100 bg-purple-50/30 py-2.5 pl-10 pr-4 text-sm text-purple-950 outline-none transition-colors focus:border-purple-300 focus:bg-white"
              />
              <Search className="absolute left-3.5 top-3 h-4 w-4 text-purple-400" />
            </div>

            <div className="relative">
              <select
                id="sort-select"
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="appearance-none rounded-full border border-purple-100 bg-purple-50/30 py-2.5 pl-4 pr-10 text-sm text-purple-950 outline-none transition-colors focus:border-purple-300 focus:bg-white cursor-pointer"
              >
                <option value="featured">Destacados</option>
                <option value="price-low">Precio: menor a mayor</option>
                <option value="price-high">Precio: mayor a menor</option>
                <option value="rating">Mejor Calificados</option>
              </select>
              <SlidersHorizontal className="absolute right-3.5 top-3.5 h-3.5 w-3.5 pointer-events-none text-purple-400" />
            </div>
          </div>

        </div>

        {/* Product Grid */}
        {filteredProducts.length === 0 ? (
          <div className="text-center py-16 bg-purple-50/20 rounded-3xl border border-dashed border-purple-100">
            <Search className="h-10 w-10 text-purple-300 mx-auto mb-3" />
            <h3 className="text-lg font-bold text-purple-950">No encontramos productos</h3>
            <p className="text-sm text-gray-500 mt-1 max-w-md mx-auto">
              Intenta cambiar tu término de búsqueda o selecciona otra categoría de bienestar.
            </p>
            <button
              onClick={() => {
                setSearchQuery("");
                setSelectedCategory("all");
              }}
              className="mt-4 inline-flex items-center space-x-1.5 text-xs font-semibold text-purple-700 hover:text-purple-800"
            >
              <span>Restablecer Filtros</span>
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-y-10 gap-x-6 sm:grid-cols-2 lg:grid-cols-4">
            {filteredProducts.map((product) => (
              <div
                key={product.id}
                id={`product-card-${product.id}`}
                className="group relative flex flex-col overflow-hidden rounded-3xl border border-purple-50 bg-white p-3 transition-all duration-300 hover:-translate-y-1.5 hover:border-purple-100 hover:shadow-xl hover:shadow-purple-50"
              >
                {/* Image & Badges */}
                <div className="relative aspect-square w-full overflow-hidden rounded-2xl bg-purple-50">
                  <img
                    src={product.image}
                    alt={product.name}
                    referrerPolicy="no-referrer"
                    className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                  {product.tag && (
                    <span className="absolute top-2.5 left-2.5 rounded-full bg-purple-950/80 px-3 py-1 text-[10px] font-bold tracking-wide text-white backdrop-blur-sm">
                      {product.tag}
                    </span>
                  )}
                  <button
                    id={`view-details-btn-icon-${product.id}`}
                    onClick={() => setSelectedProduct(product)}
                    className="absolute bottom-2.5 right-2.5 flex h-8 w-8 items-center justify-center rounded-full bg-white/95 text-purple-950 shadow-md opacity-0 transition-opacity duration-300 group-hover:opacity-100 hover:bg-purple-50"
                  >
                    <Info className="h-4.5 w-4.5" />
                  </button>
                </div>

                {/* Details Content */}
                <div className="flex flex-1 flex-col pt-4">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-purple-500">
                    {product.category === "skincare"
                      ? "SKINCARE"
                      : product.category === "salud"
                      ? "BIENESTAR & SALUD"
                      : "CUIDADO PERSONAL"}
                  </span>
                  
                  <h3 className="mt-1 font-serif text-base font-bold text-purple-950 line-clamp-1">
                    {product.name}
                  </h3>
                  
                  <p className="mt-1 text-xs text-gray-500 line-clamp-2 leading-relaxed flex-1">
                    {product.description}
                  </p>

                  <div className="mt-3 flex items-center space-x-1 text-yellow-500">
                    <Star className="h-3.5 w-3.5 fill-current" />
                    <span className="text-xs font-bold text-gray-700">{product.rating.toFixed(1)}</span>
                  </div>

                  {/* Actions & Price */}
                  <div className="mt-4 flex items-center justify-between border-t border-purple-50/50 pt-3">
                    <span className="text-lg font-extrabold text-purple-950">
                      ${product.price.toFixed(2)} USD
                    </span>
                    
                    <button
                      id={`add-to-cart-btn-${product.id}`}
                      onClick={() => handleAddToCart(product)}
                      className={`flex h-10 items-center justify-center rounded-full px-4 text-xs font-bold tracking-wide transition-all active:scale-95 ${
                        addedProductId === product.id
                          ? "bg-emerald-600 text-white"
                          : "bg-purple-50 text-purple-800 hover:bg-purple-100"
                      }`}
                    >
                      {addedProductId === product.id ? (
                        <span className="flex items-center space-x-1">
                          <Check className="h-3.5 w-3.5" />
                          <span>Agregado</span>
                        </span>
                      ) : (
                        <span className="flex items-center space-x-1.5">
                          <ShoppingCart className="h-3.5 w-3.5" />
                          <span>Agregar</span>
                        </span>
                      )}
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Product Details Modal */}
        {selectedProduct && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-purple-950/40 backdrop-blur-sm animate-fade-in">
            <div 
              id="details-modal-container"
              className="relative w-full max-w-3xl overflow-y-auto rounded-3xl bg-white p-6 shadow-2xl max-h-[90vh] sm:p-8 animate-in zoom-in-95 duration-300"
            >
              {/* Close Button */}
              <button
                id="close-details-modal"
                onClick={() => setSelectedProduct(null)}
                className="absolute right-4 top-4 flex h-8 w-8 items-center justify-center rounded-full bg-purple-50 text-purple-900 hover:bg-purple-100"
              >
                ✕
              </button>

              <div className="grid grid-cols-1 md:grid-cols-12 gap-6 sm:gap-8 pt-4">
                {/* Image Section */}
                <div className="md:col-span-5">
                  <div className="relative overflow-hidden rounded-2xl bg-purple-50">
                    <img
                      src={selectedProduct.image}
                      alt={selectedProduct.name}
                      referrerPolicy="no-referrer"
                      className="w-full object-cover aspect-square"
                    />
                  </div>
                  <div className="mt-4 rounded-2xl bg-purple-50/50 p-4 border border-purple-100/30">
                    <h4 className="text-xs font-bold text-purple-950 uppercase tracking-wider mb-1">
                      🔬 Sello de Calidad MARSHOL
                    </h4>
                    <p className="text-[10px] text-gray-500 leading-relaxed">
                      Elaborado en pequeños lotes artesanales. 100% libre de parabenos, fragancias artificiales y sulfatos. Envase de vidrio reciclable.
                    </p>
                  </div>
                </div>

                {/* Information Section */}
                <div className="md:col-span-7 space-y-4">
                  <div>
                    <span className="text-xs font-bold uppercase tracking-widest text-purple-600">
                      {selectedProduct.category === "skincare" ? "Skincare Alquímico" : "Suplementación & Salud"}
                    </span>
                    <h3 className="font-serif text-2xl font-extrabold text-purple-950 mt-1">
                      {selectedProduct.name}
                    </h3>
                    <div className="mt-2 flex items-center justify-between">
                      <span className="text-2xl font-extrabold text-purple-950">
                        ${selectedProduct.price.toFixed(2)} USD
                      </span>
                      <div className="flex items-center space-x-1 text-yellow-500">
                        <Star className="h-4 w-4 fill-current" />
                        <span className="text-sm font-bold text-gray-700">{selectedProduct.rating.toFixed(1)}</span>
                      </div>
                    </div>
                  </div>

                  <p className="text-sm text-gray-600 leading-relaxed">
                    {selectedProduct.fullDescription}
                  </p>

                  {/* Tabs/Accordion for Benefits, Ingredients & Ritual */}
                  <div className="space-y-3">
                    <div>
                      <h4 className="text-xs font-bold uppercase tracking-wider text-purple-950 mb-1.5">
                        💜 Beneficios Clave:
                      </h4>
                      <ul className="text-xs text-gray-600 space-y-1">
                        {selectedProduct.benefits.map((benefit, idx) => (
                          <li key={idx} className="flex items-start space-x-1">
                            <span className="text-purple-600 mr-1">•</span>
                            <span>{benefit}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div>
                      <h4 className="text-xs font-bold uppercase tracking-wider text-purple-950 mb-1.5">
                        🌿 Ingredientes Destacados:
                      </h4>
                      <div className="flex flex-wrap gap-1">
                        {selectedProduct.ingredients.map((ing, idx) => (
                          <span key={idx} className="rounded-full bg-purple-50 px-2.5 py-1 text-[10px] font-medium text-purple-800 border border-purple-100/50">
                            {ing}
                          </span>
                        ))}
                      </div>
                    </div>

                    <div className="rounded-xl bg-purple-50/50 p-3.5 border border-purple-100/30">
                      <h4 className="text-xs font-bold uppercase tracking-wider text-purple-950 mb-1">
                        🌙 El Ritual de Transformación MARSHOL:
                      </h4>
                      <p className="text-[11px] text-purple-950 leading-relaxed italic">
                        "{selectedProduct.ritual}"
                      </p>
                    </div>
                  </div>

                  {/* Modal Footer Actions */}
                  <div className="flex flex-col sm:flex-row gap-3 pt-2">
                    <button
                      id="details-add-to-cart"
                      onClick={() => {
                        handleAddToCart(selectedProduct);
                        setSelectedProduct(null);
                      }}
                      className="flex-1 rounded-full bg-purple-700 py-3 text-center text-sm font-semibold text-white shadow-md shadow-purple-100 hover:bg-purple-800 transition-colors"
                    >
                      Añadir al Carrito
                    </button>
                    
                    <button
                      id="ask-coach-about-product"
                      onClick={() => {
                        onOpenCoachWithProduct(selectedProduct.name);
                        setSelectedProduct(null);
                      }}
                      className="flex-1 rounded-full border-2 border-purple-200 py-3 text-center text-sm font-semibold text-purple-900 hover:bg-purple-50 transition-colors flex items-center justify-center space-x-1"
                    >
                      <span>Consultar con Coach IA</span>
                      <ArrowRight className="h-4 w-4" />
                    </button>
                  </div>

                </div>
              </div>
            </div>
          </div>
        )}

      </div>
    </section>
  );
}
