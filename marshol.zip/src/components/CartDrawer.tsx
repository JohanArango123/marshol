import { useState } from "react";
import { X, Trash2, Plus, Minus, ShoppingBag, Gift, Sparkles } from "lucide-react";
import { CartItem } from "../types";

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  onUpdateQuantity: (productId: string, quantity: number) => void;
  onRemoveItem: (productId: string) => void;
  onCheckout: () => void;
}

export default function CartDrawer({
  isOpen,
  onClose,
  cart,
  onUpdateQuantity,
  onRemoveItem,
  onCheckout,
}: CartDrawerProps) {
  const [promoCode, setPromoCode] = useState("");
  const [discountPercent, setDiscountPercent] = useState(0);
  const [promoError, setPromoError] = useState("");
  const [promoApplied, setPromoApplied] = useState("");

  if (!isOpen) return null;

  const subtotal = cart.reduce((acc, item) => acc + item.product.price * item.quantity, 0);

  const applyPromo = () => {
    const code = promoCode.trim().toUpperCase();
    if (code === "TRANSFORMACION" || code === "MARSHOL15") {
      setDiscountPercent(15);
      setPromoApplied(code);
      setPromoError("");
    } else if (code === "BIENVENIDA" || code === "BIENESTAR") {
      setDiscountPercent(10);
      setPromoApplied(code);
      setPromoError("");
    } else {
      setPromoError("Código de descuento no válido.");
    }
  };

  const removePromo = () => {
    setDiscountPercent(0);
    setPromoApplied("");
    setPromoCode("");
  };

  const discountAmount = subtotal * (discountPercent / 100);
  const total = subtotal - discountAmount;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden" id="cart-drawer-container">
      {/* Backdrop */}
      <div 
        onClick={onClose} 
        className="absolute inset-0 bg-purple-950/40 backdrop-blur-xs transition-opacity animate-fade-in"
      />

      <div className="absolute inset-y-0 right-0 flex max-w-full pl-10">
        <div className="w-screen max-w-md transform bg-white shadow-2xl transition-transform animate-in slide-in-from-right duration-300">
          <div className="flex h-full flex-col bg-white">
            
            {/* Header */}
            <div className="flex items-center justify-between border-b border-purple-50 px-6 py-5">
              <div className="flex items-center space-x-2">
                <ShoppingBag className="h-5 w-5 text-purple-700" />
                <h2 className="text-lg font-bold text-purple-950">Tu Carrito de Bienestar</h2>
              </div>
              <button
                id="close-cart-drawer"
                onClick={onClose}
                className="rounded-full p-1.5 text-gray-400 hover:bg-purple-50 hover:text-purple-900 transition-colors"
              >
                <X className="h-6 w-6" />
              </button>
            </div>

            {/* Content Area */}
            <div className="flex-1 overflow-y-auto px-6 py-4 scrollbar-thin">
              {cart.length === 0 ? (
                <div className="flex h-[60%] flex-col items-center justify-center text-center">
                  <div className="flex h-16 w-16 items-center justify-center rounded-full bg-purple-50 text-purple-600 mb-4">
                    <ShoppingBag className="h-8 w-8" />
                  </div>
                  <h3 className="text-base font-bold text-purple-950">Tu carrito está vacío</h3>
                  <p className="text-xs text-gray-500 mt-1 max-w-xs leading-relaxed">
                    Comienza a explorar nuestro catálogo boutique y agrega productos diseñados para tu ritual de transformación diaria.
                  </p>
                  <button
                    onClick={onClose}
                    className="mt-6 rounded-full bg-purple-700 px-6 py-2.5 text-xs font-semibold text-white shadow-md hover:bg-purple-800 transition-colors"
                  >
                    Empezar a Comprar
                  </button>
                </div>
              ) : (
                <div className="space-y-4">
                  {cart.map((item) => (
                    <div
                      key={item.product.id}
                      className="flex items-center space-x-4 rounded-2xl border border-purple-50 p-3 bg-purple-50/10"
                    >
                      <img
                        src={item.product.image}
                        alt={item.product.name}
                        referrerPolicy="no-referrer"
                        className="h-16 w-16 shrink-0 rounded-xl object-cover bg-purple-50"
                      />
                      <div className="flex-1 min-w-0">
                        <h4 className="font-serif text-sm font-bold text-purple-950 line-clamp-1">
                          {item.product.name}
                        </h4>
                        <p className="text-xs text-purple-600 font-semibold mt-0.5">
                          ${item.product.price.toFixed(2)} USD
                        </p>
                        
                        {/* Quantity Controls */}
                        <div className="flex items-center space-x-2.5 mt-2">
                          <button
                            id={`qty-decrease-${item.product.id}`}
                            onClick={() => onUpdateQuantity(item.product.id, item.quantity - 1)}
                            className="flex h-6 w-6 items-center justify-center rounded-full bg-white border border-purple-100 text-purple-800 hover:bg-purple-50 active:scale-90"
                          >
                            <Minus className="h-3 w-3" />
                          </button>
                          <span className="text-xs font-bold text-gray-700 w-4 text-center">
                            {item.quantity}
                          </span>
                          <button
                            id={`qty-increase-${item.product.id}`}
                            onClick={() => onUpdateQuantity(item.product.id, item.quantity + 1)}
                            className="flex h-6 w-6 items-center justify-center rounded-full bg-white border border-purple-100 text-purple-800 hover:bg-purple-50 active:scale-90"
                          >
                            <Plus className="h-3 w-3" />
                          </button>
                        </div>
                      </div>

                      {/* Remove item */}
                      <button
                        id={`remove-item-${item.product.id}`}
                        onClick={() => onRemoveItem(item.product.id)}
                        className="text-gray-400 hover:text-rose-600 p-1 rounded-full hover:bg-rose-50 transition-colors"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Footer Summary (Only if cart has items) */}
            {cart.length > 0 && (
              <div className="border-t border-purple-100 bg-purple-50/30 px-6 py-6 space-y-4">
                
                {/* Coupon Input */}
                {!promoApplied ? (
                  <div className="space-y-1">
                    <div className="flex gap-2">
                      <input
                        type="text"
                        placeholder="Código de cupón (ej: TRANSFORMACION)"
                        value={promoCode}
                        onChange={(e) => setPromoCode(e.target.value)}
                        className="flex-1 rounded-xl border border-purple-100 bg-white px-3.5 py-2 text-xs text-purple-950 outline-none focus:border-purple-300 uppercase"
                      />
                      <button
                        onClick={applyPromo}
                        className="rounded-xl bg-purple-950 px-4 py-2 text-xs font-semibold text-white hover:bg-purple-900 transition-colors"
                      >
                        Aplicar
                      </button>
                    </div>
                    {promoError && <p className="text-[10px] text-rose-600 font-medium pl-1">{promoError}</p>}
                    <p className="text-[10px] text-purple-500 pl-1">Tip: Usa **TRANSFORMACION** para un 15% de descuento.</p>
                  </div>
                ) : (
                  <div className="flex items-center justify-between rounded-xl bg-emerald-50 px-3 py-2 border border-emerald-100">
                    <span className="flex items-center space-x-1 text-xs font-semibold text-emerald-800">
                      <Gift className="h-3.5 w-3.5 animate-pulse" />
                      <span>Descuento aplicado: {promoApplied} (-{discountPercent}%)</span>
                    </span>
                    <button
                      onClick={removePromo}
                      className="text-xs text-rose-600 font-bold hover:underline"
                    >
                      Remover
                    </button>
                  </div>
                )}

                {/* Subtotal Calculations */}
                <div className="space-y-2">
                  <div className="flex justify-between text-xs text-gray-600">
                    <span>Subtotal de productos</span>
                    <span>${subtotal.toFixed(2)} USD</span>
                  </div>
                  {discountPercent > 0 && (
                    <div className="flex justify-between text-xs text-emerald-700 font-medium">
                      <span>Descuento Especial</span>
                      <span>-${discountAmount.toFixed(2)} USD</span>
                    </div>
                  )}
                  <div className="flex justify-between text-xs text-gray-600">
                    <span>Envío Nacional</span>
                    <span className="text-emerald-700 font-semibold uppercase tracking-wide">Gratis 💜</span>
                  </div>
                  
                  <div className="h-px bg-purple-100/60 my-2"></div>
                  
                  <div className="flex justify-between items-end">
                    <span className="text-sm font-extrabold text-purple-950">Total Estimado</span>
                    <span className="text-xl font-black text-purple-950">
                      ${total.toFixed(2)} USD
                    </span>
                  </div>
                </div>

                {/* Secure checkout info */}
                <div className="flex items-center justify-center space-x-1.5 text-[10px] text-gray-500 font-medium py-1">
                  <Sparkles className="h-3 w-3 text-purple-600" />
                  <span>Tu envío incluye una muestra gratis de adaptógenos botánicos.</span>
                </div>

                {/* Launch checkout button */}
                <button
                  id="checkout-trigger-btn"
                  onClick={onCheckout}
                  className="w-full rounded-full bg-purple-700 py-3.5 text-center text-sm font-semibold text-white shadow-lg shadow-purple-100 hover:bg-purple-800 transition-colors"
                >
                  Proceder al Pago Seguro
                </button>
              </div>
            )}

          </div>
        </div>
      </div>
    </div>
  );
}
