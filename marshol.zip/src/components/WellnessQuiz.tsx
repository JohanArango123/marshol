import { useState } from "react";
import { Sparkles, ArrowRight, AlertTriangle, FileText, Check, Award, Compass, RefreshCw } from "lucide-react";
import { QuizAnswers } from "../types";

interface WellnessQuizProps {
  isOpen: boolean;
  onClose: () => void;
  onShowBoutique: () => void;
}

export default function WellnessQuiz({ isOpen, onClose, onShowBoutique }: WellnessQuizProps) {
  const [step, setStep] = useState<number>(0);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [report, setReport] = useState<string>("");
  const [error, setError] = useState<string>("");

  const [answers, setAnswers] = useState<QuizAnswers>({
    skinType: "",
    mainConcern: "",
    stressLevel: "",
    physicalEnergy: "",
    sleepQuality: "",
    transformationGoal: "",
  });

  if (!isOpen) return null;

  const questions = [
    {
      id: "skinType",
      title: "1. ¿Cómo se siente tu piel la mayor parte del tiempo?",
      subtitle: "Pilar de belleza • Diagnóstico de epidermis",
      options: [
        { value: "Seca / Deshidratada", label: "Tirante, áspera o con descamación ligera.", icon: "🏜️" },
        { value: "Grasa / Con Brillo", label: "Brillo constante en la zona T o brotes ocasionales.", icon: "✨" },
        { value: "Mixta", label: "Grasa en algunas zonas (frente, nariz) y seca en mejillas.", icon: "🌗" },
        { value: "Sensible / Con Rojeces", label: "Se irrita fácilmente con productos o cambios de clima.", icon: "🌸" },
      ],
    },
    {
      id: "mainConcern",
      title: "2. ¿Cuál es tu preocupación principal respecto a tu piel?",
      subtitle: "Pilar de belleza • Objetivo prioritario",
      options: [
        { value: "Líneas de expresión y firmeza", label: "Quiero prevenir arrugas y redefinir la elasticidad.", icon: "⏳" },
        { value: "Falta de brillo y opacidad", label: "Siento mi piel apagada, con tono desigual y manchas.", icon: "💡" },
        { value: "Poros dilatados e impurezas", label: "Busco una textura más lisa y libre de puntos negros.", icon: "🧼" },
        { value: "Sensibilidad y deshidratación", label: "Deseo calmar rojeces, picazón e hidratar profundamente.", icon: "💧" },
      ],
    },
    {
      id: "stressLevel",
      title: "3. ¿Cómo describirías tu nivel de estrés mental diario?",
      subtitle: "Pilar de transformación • Sistema Nervioso",
      options: [
        { value: "Muy Alto (Mente acelerada)", label: "Pensamientos constantes, ansiedad o sobrecarga mental.", icon: "🌪️" },
        { value: "Moderado (Soportable pero presente)", label: "Estrés laboral o cotidiano, pero logro controlarlo a veces.", icon: "⚖️" },
        { value: "Bajo (Relajado y en equilibrio)", label: "Me siento tranquilo, en balance y con paz interior.", icon: "🧘" },
      ],
    },
    {
      id: "physicalEnergy",
      title: "4. ¿Cómo calificarías tu energía física al despertar?",
      subtitle: "Pilar de salud • Vitalidad celular",
      options: [
        { value: "Baja (Cansancio al despertar)", label: "Siento pesadez en el cuerpo y dependo del café.", icon: "🔋" },
        { value: "Fluctuante (Energía inestable)", label: "Inició bien, pero tengo un bajón drástico por la tarde.", icon: "📈" },
        { value: "Alta y enfocada", label: "Me levanto con ligereza, claridad mental y vigor físico.", icon: "☀️" },
      ],
    },
    {
      id: "sleepQuality",
      title: "5. ¿Cómo calificarías la calidad de tu descanso nocturno?",
      subtitle: "Pilar de salud • Sueño y reparación",
      options: [
        { value: "Mala (Me despierto mucho)", label: "Sueño superficial, insomnio o dificultad para conciliar.", icon: "🦉" },
        { value: "Regular (Me cuesta conciliar)", label: "Duermo pero despierto cansado o tardo en dormir.", icon: "⏳" },
        { value: "Excelente (Profundo y reparador)", label: "Duermo de corrido entre 7 y 8 horas y amanezco renovado.", icon: "🌙" },
      ],
    },
    {
      id: "transformationGoal",
      title: "6. ¿Cuál es tu meta de transformación integral más deseada?",
      subtitle: "Pilar de transformación • Propósito sagrado",
      options: [
        { value: "Rejuvenecer mi piel y sanar rojeces", label: "Quiero recuperar la juventud y salud de mi rostro.", icon: "🌹" },
        { value: "Calmar la ansiedad y dormir mejor", label: "Deseo serenidad mental, dormir profundamente y relajarme.", icon: "🕊️" },
        { value: "Aumentar mi vitalidad y foco diario", label: "Quiero potenciar mi rendimiento físico y claridad.", icon: "⚡" },
        { value: "Ritual completo de amor propio", label: "Integrar skincare, salud y hábitos espirituales en mi vida.", icon: "💜" },
      ],
    },
  ];

  const handleSelectOption = (value: string) => {
    const currentQuestionKey = questions[step].id as keyof QuizAnswers;
    setAnswers((prev) => ({ ...prev, [currentQuestionKey]: value }));

    if (step < questions.length - 1) {
      setStep((prev) => prev + 1);
    } else {
      handleSubmitAnswers({ ...answers, [currentQuestionKey]: value });
    }
  };

  const handleSubmitAnswers = async (finalAnswers: QuizAnswers) => {
    setIsLoading(true);
    setError("");
    try {
      const response = await fetch("/api/wellness-diagnosis", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ answers: finalAnswers }),
      });

      if (!response.ok) {
        throw new Error("No pudimos generar tu diagnóstico. Intenta de nuevo.");
      }

      const data = await response.json();
      setReport(data.report);
      setStep(questions.length); // Advance to results page
    } catch (err: any) {
      console.error(err);
      setError("Ocurrió un error al conectar con nuestra Coach de IA. Por favor intenta de nuevo.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleRestart = () => {
    setAnswers({
      skinType: "",
      mainConcern: "",
      stressLevel: "",
      physicalEnergy: "",
      sleepQuality: "",
      transformationGoal: "",
    });
    setStep(0);
    setReport("");
    setError("");
  };

  const formatReportText = (text: string) => {
    return text.split("\n").map((line, i) => {
      let formattedLine = line;

      // Handle simple markdown headers (### or **)
      if (line.startsWith("### ")) {
        return (
          <h4 key={i} className="text-sm font-bold text-purple-950 mt-5 mb-2 first:mt-0 uppercase tracking-wider flex items-center space-x-2">
            <span className="text-purple-600">✦</span>
            <span>{line.replace("### ", "")}</span>
          </h4>
        );
      }
      if (line.startsWith("## ")) {
        return (
          <h3 key={i} className="text-base font-extrabold text-purple-950 mt-6 mb-3 first:mt-0 tracking-tight border-b border-purple-100 pb-1.5 flex items-center space-x-2">
            <Sparkles className="h-4 w-4 text-purple-700" />
            <span>{line.replace("## ", "")}</span>
          </h3>
        );
      }
      if (line.startsWith("# ")) {
        return (
          <h2 key={i} className="font-serif text-lg font-black text-purple-950 mt-4 mb-3 text-center uppercase tracking-widest bg-purple-50 py-2 rounded-xl border border-purple-100/50">
            {line.replace("# ", "")}
          </h2>
        );
      }

      // Bullet lists
      if (line.startsWith("* ") || line.startsWith("- ")) {
        const bulletText = line.replace(/^[\*\-]\s+/, "");
        return (
          <li key={i} className="ml-5 list-disc pl-1 text-xs text-gray-600 leading-relaxed my-1.5">
            {parseBoldText(bulletText)}
          </li>
        );
      }

      // Numbers list
      if (/^\d+\.\s+/.test(line)) {
        const listText = line.replace(/^\d+\.\s+/, "");
        const num = line.match(/^\d+/)![0];
        return (
          <div key={i} className="flex items-start space-x-2 my-2.5 pl-1">
            <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-purple-100 text-[10px] font-bold text-purple-800">
              {num}
            </span>
            <p className="text-xs text-gray-600 leading-relaxed">{parseBoldText(listText)}</p>
          </div>
        );
      }

      return (
        <p key={i} className="text-xs text-gray-600 leading-relaxed my-2">
          {parseBoldText(formattedLine)}
        </p>
      );
    });
  };

  const parseBoldText = (text: string) => {
    const parts = text.split(/\*\*([^*]+)\*\*/g);
    return parts.map((part, index) => {
      if (index % 2 === 1) {
        return <strong key={index} className="text-purple-950 font-extrabold bg-purple-50/60 px-0.5 rounded">{part}</strong>;
      }
      return part;
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-purple-950/45 backdrop-blur-md animate-fade-in" id="quiz-modal-container">
      <div className="relative w-full max-w-2xl overflow-hidden rounded-[2.2rem] bg-white shadow-2xl animate-in zoom-in-95 duration-300">
        
        {/* Top brand header border */}
        <div className="h-2 bg-gradient-to-r from-purple-700 via-indigo-600 to-violet-600"></div>

        {/* Modal Header */}
        <div className="flex items-center justify-between border-b border-purple-50 px-6 py-4.5 bg-purple-50/20">
          <div className="flex items-center space-x-2">
            <Sparkles className="h-5 w-5 text-purple-700 animate-pulse" />
            <span className="font-serif text-sm font-bold tracking-[0.1em] text-purple-950">
              MARSHOL DIAGNÓSTICO INTEGRAL
            </span>
          </div>
          <button
            id="close-quiz-modal"
            onClick={onClose}
            className="rounded-full p-1 text-gray-400 hover:bg-purple-100 hover:text-purple-900 transition-colors"
          >
            ✕
          </button>
        </div>

        {/* Diagnostic Quiz Progress bar */}
        {step < questions.length && (
          <div className="w-full bg-purple-100/50 h-1.5">
            <div 
              id="quiz-progress-bar"
              className="bg-purple-700 h-1.5 transition-all duration-300"
              style={{ width: `${((step + 1) / questions.length) * 100}%` }}
            ></div>
          </div>
        )}

        {/* Scrollable Main content area */}
        <div className="overflow-y-auto px-6 py-6 sm:px-8 max-h-[75vh] scrollbar-thin">
          
          {isLoading ? (
            /* Loading State */
            <div className="text-center py-12 space-y-6 flex flex-col items-center">
              <div className="relative flex items-center justify-center">
                {/* Custom glowing rings animation */}
                <div className="absolute h-16 w-16 animate-ping rounded-full bg-purple-400/20"></div>
                <div className="absolute h-12 w-12 animate-pulse rounded-full bg-purple-600/30"></div>
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-purple-700 text-white">
                  <Sparkles className="h-5 w-5 animate-spin-slow" />
                </div>
              </div>
              
              <div className="space-y-1.5">
                <h3 className="text-lg font-bold text-purple-950">Canalizando tu perfil holístico...</h3>
                <p className="text-xs text-gray-500 max-w-xs mx-auto leading-relaxed">
                  Nuestra Coach de Inteligencia Artificial está analizando tus respuestas de Skincare, Niveles de Estrés y Metabolismo para diseñar tu plan personalizado de transformación.
                </p>
              </div>

              {/* Sequential loading checklist */}
              <div className="text-left bg-purple-50/50 rounded-2xl p-4 border border-purple-100/30 max-w-sm w-full space-y-2 text-[11px] text-purple-950 font-medium">
                <div className="flex items-center space-x-2">
                  <Check className="h-3.5 w-3.5 text-emerald-600 animate-pulse" />
                  <span>1. Evaluando compatibilidad cutánea botánica...</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Check className="h-3.5 w-3.5 text-emerald-600 animate-pulse" />
                  <span>2. Calibrando balance del sistema nervioso...</span>
                </div>
                <div className="flex items-center space-x-2">
                  <span className="inline-block h-2 w-2 rounded-full bg-purple-500 animate-ping"></span>
                  <span>3. Generando recetario herbolario y ritual diario...</span>
                </div>
              </div>
            </div>
          ) : error ? (
            /* Error State */
            <div className="text-center py-10 space-y-4">
              <AlertTriangle className="h-10 w-10 text-rose-600 mx-auto" />
              <h3 className="text-base font-bold text-purple-950">Error al Generar Reporte</h3>
              <p className="text-xs text-gray-500 max-w-sm mx-auto">{error}</p>
              <button
                onClick={handleRestart}
                className="rounded-full bg-purple-700 px-6 py-2 text-xs font-semibold text-white shadow-md hover:bg-purple-800"
              >
                Reintentar Diagnóstico
              </button>
            </div>
          ) : step < questions.length ? (
            /* Question State */
            <div className="space-y-6">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-widest text-purple-600">
                  {questions[step].subtitle}
                </span>
                <h3 className="font-serif text-lg font-bold text-purple-950 mt-1">
                  {questions[step].title}
                </h3>
              </div>

              <div className="grid grid-cols-1 gap-3.5">
                {questions[step].options.map((opt, idx) => (
                  <button
                    key={idx}
                    id={`quiz-option-${step}-${idx}`}
                    onClick={() => handleSelectOption(opt.value)}
                    className="flex items-center space-x-4 rounded-2xl border border-purple-100 bg-purple-50/10 p-4 text-left transition-all duration-300 hover:border-purple-300 hover:bg-purple-50/40 hover:shadow-md hover:scale-[1.01] active:scale-[0.99] group"
                  >
                    <span className="text-2xl filter drop-shadow-sm group-hover:scale-110 transition-transform">
                      {opt.icon}
                    </span>
                    <div>
                      <h4 className="text-xs font-bold text-purple-950 group-hover:text-purple-700 transition-colors">
                        {opt.value}
                      </h4>
                      <p className="text-[10px] text-gray-500 mt-0.5 leading-relaxed">
                        {opt.label}
                      </p>
                    </div>
                  </button>
                ))}
              </div>

              {/* Navigation Footer */}
              <div className="flex justify-between items-center pt-2 text-[10px] text-gray-400 border-t border-purple-50">
                <span>Paso {step + 1} de {questions.length}</span>
                {step > 0 && (
                  <button
                    onClick={() => setStep((prev) => prev - 1)}
                    className="font-bold text-purple-700 hover:underline"
                  >
                    ← Regresar al anterior
                  </button>
                )}
              </div>
            </div>
          ) : (
            /* Results / Report State */
            <div className="space-y-6">
              
              {/* Report Header Visual */}
              <div className="text-center bg-purple-50/50 rounded-2xl p-4 border border-purple-100 flex flex-col items-center">
                <Award className="h-8 w-8 text-purple-700 mb-1.5" />
                <h3 className="font-serif text-lg font-bold text-purple-950">Tu Alquimia Personalizada MARSHOL</h3>
                <p className="text-[10px] text-gray-500 max-w-md mt-0.5 leading-relaxed">
                  Este plan ha sido diseñado especialmente por tu Coach AI de acuerdo a la sinergia biológica entre tu tipo de piel, energía física y balance emocional.
                </p>
              </div>

              {/* Renderized Report Body */}
              <div 
                id="quiz-diagnosis-report"
                className="bg-purple-50/10 rounded-2xl border border-purple-100/50 p-5 sm:p-6 prose max-w-none text-left space-y-2 select-text"
              >
                {formatReportText(report)}
              </div>

              {/* Report Footer Actions */}
              <div className="flex flex-col sm:flex-row gap-3 pt-3 border-t border-purple-100">
                <button
                  id="quiz-go-boutique"
                  onClick={() => {
                    onShowBoutique();
                    onClose();
                  }}
                  className="flex-1 rounded-full bg-purple-700 py-3 text-center text-xs font-semibold text-white shadow-md hover:bg-purple-800 transition-all flex items-center justify-center space-x-1"
                >
                  <Compass className="h-4 w-4" />
                  <span>Ver Productos Sugeridos en Boutique</span>
                </button>

                <button
                  id="quiz-restart"
                  onClick={handleRestart}
                  className="rounded-full border border-purple-200 bg-white px-5 py-3 text-center text-xs font-semibold text-purple-900 hover:bg-purple-50 transition-all flex items-center justify-center space-x-1"
                >
                  <RefreshCw className="h-3.5 w-3.5" />
                  <span>Hacer Diagnóstico de Nuevo</span>
                </button>
              </div>

            </div>
          )}

        </div>

      </div>
    </div>
  );
}
