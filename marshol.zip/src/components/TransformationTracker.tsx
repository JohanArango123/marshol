import React, { useState, useEffect } from "react";
import { CheckCircle, Circle, Flame, Sparkles, Plus, Trash2, Moon, Sun, Award, HelpCircle } from "lucide-react";
import { Habit } from "../types";
import { DEFAULT_HABITS } from "../data";

export default function TransformationTracker() {
  const [habits, setHabits] = useState<Habit[]>(() => {
    const saved = localStorage.getItem("marshol_habits");
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error("Error reading habits from localStorage", e);
      }
    }
    return DEFAULT_HABITS;
  });

  const [points, setPoints] = useState<number>(() => {
    const saved = localStorage.getItem("marshol_points");
    return saved ? parseInt(saved, 10) : 120; // Default starting points
  });

  const [streak, setStreak] = useState<number>(() => {
    const saved = localStorage.getItem("marshol_streak");
    return saved ? parseInt(saved, 10) : 5; // Default starting streak
  });

  // Custom Habit Form State
  const [showAddForm, setShowAddForm] = useState(false);
  const [newHabitName, setNewHabitName] = useState("");
  const [newHabitCategory, setNewHabitCategory] = useState<"skincare" | "salud" | "transformacion">("skincare");
  const [newHabitTime, setNewHabitTime] = useState<"mañana" | "noche">("mañana");
  const [newHabitDesc, setNewHabitDesc] = useState("");

  // Persist State in localStorage
  useEffect(() => {
    localStorage.setItem("marshol_habits", JSON.stringify(habits));
    localStorage.setItem("marshol_points", points.toString());
    localStorage.setItem("marshol_streak", streak.toString());
  }, [habits, points, streak]);

  const handleToggleHabit = (id: string) => {
    setHabits((prev) =>
      prev.map((h) => {
        if (h.id === id) {
          const nextCompleted = !h.completed;
          const nextStreak = nextCompleted ? h.streak + 1 : Math.max(0, h.streak - 1);
          
          // Calculate points change
          if (nextCompleted) {
            setPoints((p) => p + h.points);
          } else {
            setPoints((p) => Math.max(0, p - h.points));
          }
          
          return {
            ...h,
            completed: nextCompleted,
            streak: nextStreak,
          };
        }
        return h;
      })
    );
  };

  const handleAddCustomHabit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newHabitName.trim()) return;

    const newHabit: Habit = {
      id: "custom-" + Date.now().toString(),
      name: newHabitName.trim(),
      category: newHabitCategory,
      timeOfDay: newHabitTime,
      completed: false,
      streak: 0,
      points: 10,
      description: newHabitDesc.trim() || "Un hábito personalizado para tu transformación holística.",
    };

    setHabits((prev) => [...prev, newHabit]);
    setNewHabitName("");
    setNewHabitDesc("");
    setShowAddForm(false);
  };

  const handleDeleteHabit = (id: string) => {
    if (window.confirm("¿Estás seguro de que deseas eliminar este hábito de tu ritual?")) {
      setHabits((prev) => prev.filter((h) => h.id !== id));
    }
  };

  const handleResetDay = () => {
    if (window.confirm("¿Deseas resetear tu ritual de hoy para iniciarlo de nuevo? (Mantendrás tus puntos y racha)")) {
      setHabits((prev) => prev.map((h) => ({ ...h, completed: false })));
    }
  };

  // Calculations
  const morningHabits = habits.filter((h) => h.timeOfDay === "mañana");
  const eveningHabits = habits.filter((h) => h.timeOfDay === "noche");

  const completedCount = habits.filter((h) => h.completed).length;
  const totalCount = habits.length;
  const completionPercent = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;

  // Determine emotional level based on points
  const getLevelName = (p: number) => {
    if (p < 200) return "Buscadora de Luz ✨";
    if (p < 400) return "Alquimista en Sintonía 🌸";
    if (p < 600) return "Alma Despierta 🕊️";
    return "Emperatriz de Transformación 👑";
  };

  return (
    <section className="py-12 bg-white" id="tracker-section">
      <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8">
        
        {/* Title Block */}
        <div className="text-center max-w-2xl mx-auto mb-10">
          <h2 className="font-serif text-3xl font-extrabold tracking-tight text-purple-950 sm:text-4xl">
            Mi Ritual de Transformación
          </h2>
          <div className="h-1 w-20 bg-purple-600 mx-auto my-3 rounded-full"></div>
          <p className="text-sm text-gray-600">
            Pequeños pasos de amor propio diarios. Tacha tus rutinas de skincare y salud integral para acumular Puntos de Alquimia y monitorear tu florecimiento personal.
          </p>
        </div>

        {/* Dashboard Cards: Streaks and Levels */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5 mb-10">
          
          {/* Streak Card */}
          <div className="rounded-3xl bg-gradient-to-br from-amber-50 to-orange-50 border border-orange-100 p-5 flex items-center space-x-4">
            <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-orange-600 text-white shadow-md shadow-orange-100">
              <Flame className="h-6 w-6 animate-pulse" />
            </div>
            <div>
              <span className="block text-[10px] font-bold uppercase tracking-wider text-orange-700">Racha de Bienestar</span>
              <div className="flex items-baseline space-x-1.5">
                <span className="text-2xl font-black text-orange-950">{streak}</span>
                <span className="text-xs text-orange-800 font-semibold">Días seguidos</span>
              </div>
            </div>
          </div>

          {/* Points/Alquimia Card */}
          <div className="rounded-3xl bg-gradient-to-br from-purple-50 to-indigo-50 border border-purple-100 p-5 flex items-center space-x-4">
            <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-purple-700 text-white shadow-md shadow-purple-100">
              <Sparkles className="h-6 w-6" />
            </div>
            <div>
              <span className="block text-[10px] font-bold uppercase tracking-wider text-purple-700">Puntos de Alquimia</span>
              <div className="flex items-baseline space-x-1.5">
                <span className="text-2xl font-black text-purple-950">{points}</span>
                <span className="text-xs text-purple-800 font-semibold">Puntos acumulados</span>
              </div>
            </div>
          </div>

          {/* Spiritual Level Card */}
          <div className="rounded-3xl bg-gradient-to-br from-violet-50 to-indigo-50 border border-violet-100 p-5 flex items-center space-x-4">
            <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-indigo-600 text-white shadow-md shadow-indigo-100">
              <Award className="h-6 w-6" />
            </div>
            <div>
              <span className="block text-[10px] font-bold uppercase tracking-wider text-indigo-700">Estado de Sintonía</span>
              <span className="block text-sm font-extrabold text-indigo-950 mt-0.5 leading-snug">
                {getLevelName(points)}
              </span>
            </div>
          </div>

        </div>

        {/* Global Progress Bar */}
        <div className="bg-purple-50 rounded-3xl p-6 border border-purple-100/60 mb-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="flex-1 space-y-2">
            <div className="flex justify-between items-center text-sm font-bold text-purple-950">
              <span>Progreso de Ritual de Hoy</span>
              <span className="text-purple-700 font-extrabold text-base">{completionPercent}%</span>
            </div>
            <div className="w-full bg-purple-100 h-3 rounded-full overflow-hidden">
              <div 
                className="bg-purple-700 h-3 rounded-full transition-all duration-500"
                style={{ width: `${completionPercent}%` }}
              ></div>
            </div>
            <p className="text-[10px] text-gray-500 font-medium italic">
              ✦ Completado: {completedCount} de {totalCount} rituales del día.
            </p>
          </div>

          {/* Reset / Add Custom Controls */}
          <div className="flex gap-3">
            <button
              id="show-add-habit-form"
              onClick={() => setShowAddForm(true)}
              className="flex items-center space-x-1.5 rounded-full bg-purple-700 px-5 py-3 text-xs font-semibold text-white shadow-md shadow-purple-100 hover:bg-purple-800 transition-all active:scale-95"
            >
              <Plus className="h-3.5 w-3.5" />
              <span>Añadir Hábito</span>
            </button>
            
            <button
              id="reset-today-habits"
              onClick={handleResetDay}
              className="rounded-full border border-purple-200 bg-white px-5 py-3 text-xs font-semibold text-purple-900 shadow-sm hover:bg-purple-50 transition-all active:scale-95"
            >
              Resetear Día
            </button>
          </div>
        </div>

        {/* Custom Habit Creator Form Modal Popup */}
        {showAddForm && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-purple-950/40 backdrop-blur-xs animate-fade-in">
            <div className="relative w-full max-w-md rounded-3xl bg-white p-6 shadow-2xl animate-in zoom-in-95 duration-200">
              <button
                onClick={() => setShowAddForm(false)}
                className="absolute right-4 top-4 text-gray-400 hover:text-gray-600 font-bold p-1 rounded-full hover:bg-gray-50"
              >
                ✕
              </button>
              
              <h3 className="font-serif text-lg font-bold text-purple-950 mb-4">Añadir Hábito de Bienestar</h3>

              <form onSubmit={handleAddCustomHabit} className="space-y-4">
                <div>
                  <label className="block text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1">Nombre del Ritual *</label>
                  <input
                    type="text"
                    required
                    maxLength={35}
                    placeholder="Ej: Meditación de mañana, 2L de agua..."
                    value={newHabitName}
                    onChange={(e) => setNewHabitName(e.target.value)}
                    className="w-full rounded-xl border border-purple-100 px-3.5 py-2 text-xs outline-none focus:border-purple-400"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1">Categoría</label>
                    <select
                      value={newHabitCategory}
                      onChange={(e: any) => setNewHabitCategory(e.target.value)}
                      className="w-full rounded-xl border border-purple-100 px-3 py-2 text-xs outline-none focus:border-purple-400 cursor-pointer"
                    >
                      <option value="skincare">Skincare 🌸</option>
                      <option value="salud">Salud & Nutrición 🌿</option>
                      <option value="transformacion">Mindfulness 🕊️</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1">Momento del Día</label>
                    <select
                      value={newHabitTime}
                      onChange={(e: any) => setNewHabitTime(e.target.value)}
                      className="w-full rounded-xl border border-purple-100 px-3 py-2 text-xs outline-none focus:border-purple-400 cursor-pointer"
                    >
                      <option value="mañana">Mañana ☀️</option>
                      <option value="noche">Noche 🌙</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1">Descripción Corta</label>
                  <input
                    type="text"
                    maxLength={100}
                    placeholder="Describe en breves palabras tu ritual o indicación..."
                    value={newHabitDesc}
                    onChange={(e) => setNewHabitDesc(e.target.value)}
                    className="w-full rounded-xl border border-purple-100 px-3.5 py-2 text-xs outline-none focus:border-purple-400"
                  />
                </div>

                <button
                  id="submit-new-habit"
                  type="submit"
                  className="w-full rounded-xl bg-purple-700 py-3 text-center text-xs font-semibold text-white shadow-md hover:bg-purple-800 transition-colors"
                >
                  Agregar a mi Ritual Diario
                </button>
              </form>
            </div>
          </div>
        )}

        {/* Morning & Evening Columns */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          
          {/* Morning Habits Column */}
          <div className="space-y-4">
            <div className="flex items-center space-x-2 border-b border-purple-100 pb-2.5">
              <Sun className="h-5 w-5 text-amber-500" />
              <h3 className="font-serif text-lg font-bold text-purple-950">Rituales de Mañana</h3>
              <span className="rounded-full bg-amber-50 px-2.5 py-0.5 text-[10px] font-bold text-amber-700">☀️ Activar</span>
            </div>

            {morningHabits.length === 0 ? (
              <p className="text-xs text-gray-400 italic py-4">No hay rituales registrados en la mañana.</p>
            ) : (
              <div className="space-y-3">
                {morningHabits.map((habit) => (
                  <div
                    key={habit.id}
                    className={`flex items-start justify-between rounded-2xl border p-4 transition-all duration-300 ${
                      habit.completed
                        ? "border-purple-100 bg-purple-50/20 opacity-75"
                        : "border-purple-50 bg-white hover:border-purple-200 hover:shadow-sm"
                    }`}
                  >
                    <div className="flex items-start space-x-3.5">
                      <button
                        id={`toggle-habit-${habit.id}`}
                        onClick={() => handleToggleHabit(habit.id)}
                        className="mt-0.5 text-purple-600 hover:scale-105 active:scale-95 transition-transform"
                      >
                        {habit.completed ? (
                          <CheckCircle className="h-5 w-5 fill-purple-600 text-white" />
                        ) : (
                          <Circle className="h-5 w-5 text-purple-200" />
                        )}
                      </button>
                      
                      <div className="space-y-0.5">
                        <span className={`text-[9px] font-bold uppercase tracking-wider ${
                          habit.category === "skincare"
                            ? "text-pink-500"
                            : habit.category === "salud"
                            ? "text-emerald-600"
                            : "text-indigo-600"
                        }`}>
                          {habit.category === "skincare" ? "Skincare" : habit.category === "salud" ? "Salud" : "Mente"}
                        </span>
                        <h4 className={`text-xs font-bold text-purple-950 leading-snug ${habit.completed && "line-through text-gray-400"}`}>
                          {habit.name}
                        </h4>
                        <p className="text-[10px] text-gray-500 leading-relaxed">
                          {habit.description}
                        </p>
                      </div>
                    </div>

                    <div className="flex flex-col items-end justify-between self-stretch pl-2">
                      <span className="flex items-center space-x-0.5 text-[10px] font-black text-orange-600">
                        <Flame className="h-3 w-3 fill-current" />
                        <span>{habit.streak}d</span>
                      </span>
                      {habit.id.startsWith("custom-") && (
                        <button
                          id={`delete-habit-${habit.id}`}
                          onClick={() => handleDeleteHabit(habit.id)}
                          className="text-gray-400 hover:text-rose-600 p-0.5 rounded transition-colors"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Evening Habits Column */}
          <div className="space-y-4">
            <div className="flex items-center space-x-2 border-b border-purple-100 pb-2.5">
              <Moon className="h-5 w-5 text-indigo-500" />
              <h3 className="font-serif text-lg font-bold text-purple-950">Rituales de Noche</h3>
              <span className="rounded-full bg-indigo-50 px-2.5 py-0.5 text-[10px] font-bold text-indigo-700">🌙 Calmar</span>
            </div>

            {eveningHabits.length === 0 ? (
              <p className="text-xs text-gray-400 italic py-4">No hay rituales registrados en la noche.</p>
            ) : (
              <div className="space-y-3">
                {eveningHabits.map((habit) => (
                  <div
                    key={habit.id}
                    className={`flex items-start justify-between rounded-2xl border p-4 transition-all duration-300 ${
                      habit.completed
                        ? "border-purple-100 bg-purple-50/20 opacity-75"
                        : "border-purple-50 bg-white hover:border-purple-200 hover:shadow-sm"
                    }`}
                  >
                    <div className="flex items-start space-x-3.5">
                      <button
                        id={`toggle-habit-${habit.id}`}
                        onClick={() => handleToggleHabit(habit.id)}
                        className="mt-0.5 text-purple-600 hover:scale-105 active:scale-95 transition-transform"
                      >
                        {habit.completed ? (
                          <CheckCircle className="h-5 w-5 fill-purple-600 text-white" />
                        ) : (
                          <Circle className="h-5 w-5 text-purple-200" />
                        )}
                      </button>
                      
                      <div className="space-y-0.5">
                        <span className={`text-[9px] font-bold uppercase tracking-wider ${
                          habit.category === "skincare"
                            ? "text-pink-500"
                            : habit.category === "salud"
                            ? "text-emerald-600"
                            : "text-indigo-600"
                        }`}>
                          {habit.category === "skincare" ? "Skincare" : habit.category === "salud" ? "Salud" : "Mente"}
                        </span>
                        <h4 className={`text-xs font-bold text-purple-950 leading-snug ${habit.completed && "line-through text-gray-400"}`}>
                          {habit.name}
                        </h4>
                        <p className="text-[10px] text-gray-500 leading-relaxed">
                          {habit.description}
                        </p>
                      </div>
                    </div>

                    <div className="flex flex-col items-end justify-between self-stretch pl-2">
                      <span className="flex items-center space-x-0.5 text-[10px] font-black text-orange-600">
                        <Flame className="h-3 w-3 fill-current" />
                        <span>{habit.streak}d</span>
                      </span>
                      {habit.id.startsWith("custom-") && (
                        <button
                          id={`delete-habit-${habit.id}`}
                          onClick={() => handleDeleteHabit(habit.id)}
                          className="text-gray-400 hover:text-rose-600 p-0.5 rounded transition-colors"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

        </div>

      </div>
    </section>
  );
}
