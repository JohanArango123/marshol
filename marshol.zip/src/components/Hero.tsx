import { Sparkles, ArrowRight, ShieldCheck, HeartPulse, Sparkle } from "lucide-react";
import heroImageSrc from "../assets/images/marshol_hero_banner_1784250861256.jpg";

interface HeroProps {
  onExplore: () => void;
  onOpenQuiz: () => void;
}

export default function Hero({ onExplore, onOpenQuiz }: HeroProps) {

  return (
    <section className="relative overflow-hidden bg-gradient-to-b from-purple-50/50 via-white to-white py-12 md:py-20 lg:py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 items-center gap-12 lg:grid-cols-12">
          
          {/* Text Content */}
          <div className="space-y-6 lg:col-span-6 text-center lg:text-left">
            <div className="inline-flex items-center space-x-2 rounded-full bg-purple-100/60 px-4 py-1.5 text-xs font-semibold tracking-wide text-purple-800 ring-1 ring-purple-200/50">
              <Sparkle className="h-3.5 w-3.5 text-purple-600 animate-spin-slow" />
              <span>ALQUIMIA BOTÁNICA & CONSCIENCIA</span>
            </div>

            <h1 className="font-serif text-4xl font-extrabold tracking-tight text-purple-950 sm:text-5xl md:text-6xl leading-[1.1]">
              Belleza, bienestar <br />
              <span className="bg-gradient-to-r from-purple-700 via-purple-600 to-indigo-600 bg-clip-text text-transparent">
                integral & transformación
              </span>
            </h1>

            <p className="mx-auto lg:mx-0 max-w-xl text-lg text-gray-600 leading-relaxed">
              En <strong className="text-purple-900 font-medium">MARSHOL</strong> fusionamos la ciencia del skincare botánico de alta eficacia con adaptógenos de salud integral y rituales de reconexión mental. Descubre un camino de transformación que comienza en tu piel y resuena en todo tu ser. 💜
            </p>

            {/* Core Pillars Grid */}
            <div className="grid grid-cols-3 gap-3 pt-2 max-w-md mx-auto lg:mx-0">
              <div className="flex flex-col items-center lg:items-start p-3 rounded-2xl bg-purple-50/50 border border-purple-100/30 text-center lg:text-left">
                <div className="mb-2 flex h-8 w-8 items-center justify-center rounded-lg bg-purple-600 text-white shadow-sm">
                  <Sparkles className="h-4 w-4" />
                </div>
                <h3 className="text-xs font-bold text-purple-950">Skincare</h3>
                <p className="text-[10px] text-gray-500">Alta eficacia botánica</p>
              </div>

              <div className="flex flex-col items-center lg:items-start p-3 rounded-2xl bg-purple-50/50 border border-purple-100/30 text-center lg:text-left">
                <div className="mb-2 flex h-8 w-8 items-center justify-center rounded-lg bg-indigo-600 text-white shadow-sm">
                  <HeartPulse className="h-4 w-4" />
                </div>
                <h3 className="text-xs font-bold text-purple-950">Salud</h3>
                <p className="text-[10px] text-gray-500">Adaptógenos y nutrición</p>
              </div>

              <div className="flex flex-col items-center lg:items-start p-3 rounded-2xl bg-purple-50/50 border border-purple-100/30 text-center lg:text-left">
                <div className="mb-2 flex h-8 w-8 items-center justify-center rounded-lg bg-violet-600 text-white shadow-sm">
                  <ShieldCheck className="h-4 w-4" />
                </div>
                <h3 className="text-xs font-bold text-purple-950">Rituales</h3>
                <p className="text-[10px] text-gray-500">Transformación diaria</p>
              </div>
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4 pt-4">
              <button
                id="hero-primary-btn"
                onClick={onOpenQuiz}
                className="group flex w-full sm:w-auto items-center justify-center space-x-2 rounded-full bg-purple-700 px-8 py-4 text-sm font-semibold text-white shadow-xl shadow-purple-200 transition-all duration-300 hover:bg-purple-800 hover:shadow-2xl hover:scale-[1.02] active:scale-95"
              >
                <span>Descubre tu Ritual (IA)</span>
                <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
              </button>
              
              <button
                id="hero-secondary-btn"
                onClick={onExplore}
                className="flex w-full sm:w-auto items-center justify-center space-x-2 rounded-full border-2 border-purple-100 bg-white px-8 py-4 text-sm font-semibold text-purple-900 transition-all duration-300 hover:border-purple-200 hover:bg-purple-50/30 active:scale-95"
              >
                <span>Explorar Boutique</span>
              </button>
            </div>
            
            <div className="flex items-center justify-center lg:justify-start space-x-6 pt-2 text-xs text-gray-500 font-medium">
              <span className="flex items-center space-x-1">
                <span className="text-purple-600 font-bold">✓</span> <span>100% Orgánico & Vegano</span>
              </span>
              <span className="flex items-center space-x-1">
                <span className="text-purple-600 font-bold">✓</span> <span>Cruelty-Free</span>
              </span>
            </div>
          </div>

          {/* Hero Banner Image */}
          <div className="lg:col-span-6 relative flex justify-center">
            {/* Visual backdrop decorative glow */}
            <div className="absolute -inset-4 rounded-[2.5rem] bg-gradient-to-tr from-purple-300 to-indigo-300 opacity-20 blur-2xl"></div>
            
            <div className="relative overflow-hidden rounded-[2rem] border-4 border-white bg-white shadow-2xl transition-transform duration-500 hover:scale-[1.01] hover:shadow-purple-100 max-w-md lg:max-w-none">
              <img
                src={heroImageSrc}
                alt="Boutique de Bienestar MARSHOL"
                referrerPolicy="no-referrer"
                className="h-[300px] w-full object-cover sm:h-[400px] md:h-[450px]"
              />
              
              {/* Premium overlay badge */}
              <div className="absolute bottom-4 left-4 right-4 rounded-2xl bg-white/80 p-4 backdrop-blur-md border border-white/40 shadow-lg">
                <div className="flex items-center space-x-3">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-purple-700 text-white">
                    <Sparkles className="h-5 w-5 animate-pulse" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-purple-950">Cosmética Espiritual</h4>
                    <p className="text-[10px] text-gray-600">
                      Infundido con extracto de amatista para calmar cuerpo y espíritu.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
