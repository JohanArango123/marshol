import React, { useState } from "react";
import { CheckCircle2, ShieldCheck, Heart, Sparkles, MapPin, CreditCard, ChevronRight } from "lucide-react";
import { CartItem } from "../types";

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  onClearCart: () => void;
}

export default function CheckoutModal({
  isOpen,
  onClose,
  cart,
  onClearCart,
}: CheckoutModalProps) {
  const [step, setStep] = useState<"form" | "success">("form");
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Form State
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    address: "",
    city: "",
    country: "Colombia",
    cardNumber: "",
    cardExpiry: "",
    cardCvv: "",
  });

  if (!isOpen) return null;

  const total = cart.reduce((acc, item) => acc + item.product.price * item.quantity, 0);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate API network request
    setTimeout(() => {
      setIsSubmitting(false);
      setStep("success");
    }, 2000);
  };

  const handleFinish = () => {
    onClearCart();
    onClose();
    setStep("form");
  };

  // Generate random order number
  const orderNumber = "MS-" + Math.floor(Math.random() * 90000 + 10000);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-purple-950/45 backdrop-blur-sm animate-fade-in" id="checkout-modal-container">
      <div className="relative w-full max-w-2xl overflow-y-auto rounded-3xl bg-white p-6 shadow-2xl max-h-[95vh] sm:p-8 animate-in zoom-in-95 duration-300">
        
        {step === "form" ? (
          <>
            {/* Header */}
            <div className="mb-6">
              <button
                onClick={onClose}
                className="absolute right-4 top-4 text-gray-400 hover:text-gray-600 font-bold p-1 rounded-full hover:bg-gray-50"
              >
                ✕
              </button>
              <h2 className="font-serif text-2xl font-extrabold text-purple-950">Completar Pedido Holístico</h2>
              <p className="text-xs text-gray-500 mt-0.5">Disfruta de envío prioritario gratuito y un obsequio espiritual sorpresa en tu paquete.</p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
                
                {/* Shipping Details */}
                <div className="md:col-span-7 space-y-4">
                  <div className="flex items-center space-x-2 border-b border-purple-100 pb-2">
                    <MapPin className="h-4 w-4 text-purple-700" />
                    <h3 className="text-sm font-bold text-purple-950 uppercase tracking-wider">Dirección de Envío</h3>
                  </div>

                  <div className="space-y-3">
                    <div>
                      <label className="block text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1">Nombre Completo *</label>
                      <input
                        type="text"
                        name="name"
                        required
                        value={formData.name}
                        onChange={handleInputChange}
                        className="w-full rounded-xl border border-purple-100 bg-purple-50/20 px-4 py-2 text-sm outline-none focus:border-purple-400 focus:bg-white"
                        placeholder="Ej: Camila Restrepo"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="block text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1">Correo Electrónico *</label>
                        <input
                          type="email"
                          name="email"
                          required
                          value={formData.email}
                          onChange={handleInputChange}
                          className="w-full rounded-xl border border-purple-100 bg-purple-50/20 px-4 py-2 text-sm outline-none focus:border-purple-400 focus:bg-white"
                          placeholder="camila@example.com"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1">Teléfono de Contacto *</label>
                        <input
                          type="tel"
                          name="phone"
                          required
                          value={formData.phone}
                          onChange={handleInputChange}
                          className="w-full rounded-xl border border-purple-100 bg-purple-50/20 px-4 py-2 text-sm outline-none focus:border-purple-400 focus:bg-white"
                          placeholder="+57 300 123 4567"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1">Dirección de Entrega *</label>
                      <input
                        type="text"
                        name="address"
                        required
                        value={formData.address}
                        onChange={handleInputChange}
                        className="w-full rounded-xl border border-purple-100 bg-purple-50/20 px-4 py-2 text-sm outline-none focus:border-purple-400 focus:bg-white"
                        placeholder="Calle, carrera, apartamento o indicaciones..."
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="block text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1">Ciudad *</label>
                        <input
                          type="text"
                          name="city"
                          required
                          value={formData.city}
                          onChange={handleInputChange}
                          className="w-full rounded-xl border border-purple-100 bg-purple-50/20 px-4 py-2 text-sm outline-none focus:border-purple-400 focus:bg-white"
                          placeholder="Medellín"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1">País *</label>
                        <select
                          name="country"
                          value={formData.country}
                          onChange={handleInputChange}
                          className="w-full rounded-xl border border-purple-100 bg-purple-50/20 px-4 py-2 text-sm outline-none focus:border-purple-400 focus:bg-white"
                        >
                          <option value="Colombia">Colombia</option>
                          <option value="Mexico">México</option>
                          <option value="Espana">España</option>
                        </select>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Payment & Order Summary */}
                <div className="md:col-span-5 space-y-6">
                  {/* Order summary block */}
                  <div className="rounded-2xl bg-purple-50/50 p-4 border border-purple-100/40">
                    <h4 className="text-[10px] font-bold uppercase tracking-wider text-purple-950 mb-2">Resumen de Compra</h4>
                    <div className="max-h-24 overflow-y-auto space-y-1.5 scrollbar-thin mb-3">
                      {cart.map((item) => (
                        <div key={item.product.id} className="flex justify-between text-xs text-gray-600">
                          <span className="truncate max-w-[120px]">{item.product.name} (x{item.quantity})</span>
                          <span>${(item.product.price * item.quantity).toFixed(2)}</span>
                        </div>
                      ))}
                    </div>
                    <div className="h-px bg-purple-100 my-2"></div>
                    <div className="flex justify-between items-center text-sm font-extrabold text-purple-950">
                      <span>Total a Pagar</span>
                      <span>${total.toFixed(2)} USD</span>
                    </div>
                  </div>

                  {/* Payment Details */}
                  <div className="space-y-4">
                    <div className="flex items-center space-x-2 border-b border-purple-100 pb-2">
                      <CreditCard className="h-4 w-4 text-purple-700" />
                      <h3 className="text-sm font-bold text-purple-950 uppercase tracking-wider">Pago Seguro</h3>
                    </div>

                    <div className="space-y-3">
                      <div>
                        <label className="block text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1">Número de Tarjeta *</label>
                        <input
                          type="text"
                          name="cardNumber"
                          required
                          value={formData.cardNumber}
                          onChange={handleInputChange}
                          className="w-full rounded-xl border border-purple-100 bg-purple-50/20 px-4 py-2 text-sm outline-none focus:border-purple-400 focus:bg-white"
                          placeholder="4000 1234 5678 9010"
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <label className="block text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1">Expira (MM/AA) *</label>
                          <input
                            type="text"
                            name="cardExpiry"
                            required
                            value={formData.cardExpiry}
                            onChange={handleInputChange}
                            className="w-full rounded-xl border border-purple-100 bg-purple-50/20 px-4 py-2 text-sm outline-none focus:border-purple-400 focus:bg-white"
                            placeholder="12/28"
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1">CVV *</label>
                          <input
                            type="password"
                            name="cardCvv"
                            required
                            maxLength={4}
                            value={formData.cardCvv}
                            onChange={handleInputChange}
                            className="w-full rounded-xl border border-purple-100 bg-purple-50/20 px-4 py-2 text-sm outline-none focus:border-purple-400 focus:bg-white"
                            placeholder="123"
                          />
                        </div>
                      </div>
                    </div>
                  </div>

                </div>

              </div>

              {/* Secure payment shield */}
              <div className="flex items-center justify-center space-x-2 text-[10px] text-gray-500 py-2 border-t border-purple-100">
                <ShieldCheck className="h-4 w-4 text-emerald-600" />
                <span>Pago cifrado con seguridad SSL de 256 bits. Se procesa de forma simulada y 100% segura.</span>
              </div>

              {/* Submit button */}
              <button
                id="submit-checkout-form"
                type="submit"
                disabled={isSubmitting}
                className="w-full rounded-full bg-purple-700 py-3.5 text-center text-sm font-semibold text-white shadow-lg shadow-purple-100 hover:bg-purple-800 disabled:opacity-50 transition-colors flex items-center justify-center space-x-2"
              >
                {isSubmitting ? (
                  <>
                    <div className="h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent"></div>
                    <span>Procesando Alquimia...</span>
                  </>
                ) : (
                  <>
                    <span>Confirmar Pedido & Comenzar Transformación</span>
                    <ChevronRight className="h-4 w-4" />
                  </>
                )}
              </button>

            </form>
          </>
        ) : (
          /* Success Screen */
          <div className="text-center py-8 space-y-6">
            <div className="flex justify-center">
              <div className="flex h-20 w-20 items-center justify-center rounded-full bg-purple-100 text-purple-600 animate-bounce">
                <CheckCircle2 className="h-12 w-12" />
              </div>
            </div>

            <div className="space-y-2">
              <h2 className="font-serif text-3xl font-extrabold text-purple-950">¡Tu Transformación ha Comenzado!</h2>
              <p className="text-xs text-purple-600 font-bold tracking-widest uppercase">Orden confirmada • {orderNumber}</p>
              <p className="text-sm text-gray-600 max-w-md mx-auto leading-relaxed">
                ¡Gracias por confiar en <span className="font-bold text-purple-950">MARSHOL</span>, <strong>{formData.name}</strong>! Hemos recibido tu pedido y estamos preparando tu paquete con el mayor cuidado y amor del universo. 💜
              </p>
            </div>

            {/* Shipment details summary */}
            <div className="rounded-2xl bg-purple-50/50 p-5 text-left border border-purple-100 max-w-md mx-auto space-y-3 text-xs text-gray-700">
              <div className="flex items-center space-x-1.5 text-purple-900 font-bold">
                <Sparkles className="h-4 w-4" />
                <span>Detalles de Despacho:</span>
              </div>
              <p><strong>Destinatario:</strong> {formData.name}</p>
              <p><strong>Dirección de Entrega:</strong> {formData.address}, {formData.city}, {formData.country}</p>
              <p><strong>Contacto:</strong> {formData.phone} | {formData.email}</p>
              <p className="text-emerald-700 font-semibold italic">✓ Envío prioritario gratis: entrega estimada en 2-4 días hábiles.</p>
            </div>

            {/* Ritual Reminder quote */}
            <div className="max-w-md mx-auto border-l-4 border-purple-300 pl-4 py-1 text-left">
              <p className="text-xs italic text-purple-950 leading-relaxed font-serif">
                "Este no es solo un paquete de productos; es una invitación sagrada a detener el tiempo, respirar profundo, conectar con tu belleza y guiar tu propia transformación."
              </p>
              <span className="flex items-center space-x-1 mt-1.5 text-[10px] font-bold text-purple-600">
                <Heart className="h-3 w-3 fill-current" />
                <span>El Equipo de MARSHOL</span>
              </span>
            </div>

            <button
              id="checkout-finish-btn"
              onClick={handleFinish}
              className="rounded-full bg-purple-700 px-8 py-3 text-sm font-semibold text-white shadow-md hover:bg-purple-800 transition-colors"
            >
              Regresar a la Boutique
            </button>
          </div>
        )}

      </div>
    </div>
  );
}
