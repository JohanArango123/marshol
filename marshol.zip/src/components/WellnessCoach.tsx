import { useState, useRef, useEffect } from "react";
import { Send, Sparkles, RefreshCw, AlertCircle, Bot, User, CornerDownLeft, Star, Heart } from "lucide-react";
import { ChatMessage } from "../types";

interface WellnessCoachProps {
  initialMessage?: string;
  clearInitialMessage?: () => void;
}

export default function WellnessCoach({ initialMessage, clearInitialMessage }: WellnessCoachProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: "welcome",
      role: "model",
      text: "¡Hola, alma radiante! 💜 Te doy la bienvenida al espacio de consulta sagrado de **MARSHOL**.\n\nSoy tu **AI Coach de Bienestar Holístico**. Estoy aquí para ayudarte a diseñar rituales diarios de skincare botánico de alta eficacia, recomendarte suplementos naturales adaptógenos, y guiarte en tu camino de bienestar físico y transformación mental.\n\n¿De qué te gustaría hablar hoy? Puedes preguntarme cosas como:\n*   *\"Mi piel se siente seca y opaca, ¿cómo puedo devolverle el brillo?\"*\n*   *\"Siento mucha fatiga y estrés por las tardes, ¿qué adaptógenos me recomiendas?\"*\n*   *\"¿Cómo puedo armar una rutina de noche que me ayude a relajar la mente antes de dormir?\"*",
      timestamp: new Date(),
    },
  ]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");

  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Suggested Prompts
  const suggestions = [
    { text: "Mi piel se siente seca, sensible y opaca.", label: "Skincare Deshidratado 🌸" },
    { text: "Sufro de insomnio y estrés diario constante.", label: "Calmar Sistema Nervioso 🌿" },
    { text: "Quiero armar una rutina de transformación diaria.", label: "Ritual Completo 💜" },
  ];

  // Handle external initialization
  useEffect(() => {
    if (initialMessage) {
      handleSendPrompt(initialMessage);
      if (clearInitialMessage) clearInitialMessage();
    }
  }, [initialMessage]);

  // Auto-scroll to bottom of messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isLoading]);

  const handleSendPrompt = async (textToSend: string) => {
    const text = textToSend.trim();
    if (!text) return;

    setError("");
    const userMsg: ChatMessage = {
      id: Date.now().toString() + "-user",
      role: "user",
      text,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInput("");
    setIsLoading(true);

    try {
      // Build conversation history for the AI
      // Limit history to last 6 turns to avoid overloading context
      const history = messages
        .filter((msg) => msg.id !== "welcome")
        .slice(-6)
        .map((msg) => ({
          role: msg.role,
          text: msg.text,
        }));

      const response = await fetch("/api/wellness-chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          message: text,
          history,
        }),
      });

      if (!response.ok) {
        throw new Error("No se pudo conectar con el consultor AI.");
      }

      const data = await response.json();
      
      const modelMsg: ChatMessage = {
        id: Date.now().toString() + "-model",
        role: "model",
        text: data.text,
        timestamp: new Date(),
      };

      setMessages((prev) => [...prev, modelMsg]);
    } catch (err: any) {
      console.error(err);
      setError("No pudimos conectar con la Coach Holística. Intenta de nuevo.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleResetChat = () => {
    if (window.confirm("¿Deseas reiniciar tu conversación con la Coach de Bienestar?")) {
      setMessages([
        {
          id: "welcome",
          role: "model",
          text: "¡Hola, de nuevo! 💜 Soy tu **AI Coach de Bienestar Holístico** de MARSHOL. Estoy lista para continuar guiándote en tu transformación personal. ¿Qué ritual, preocupación de skincare o consulta de bienestar quieres que revisemos hoy?",
          timestamp: new Date(),
        },
      ]);
      setError("");
    }
  };

  // Helper function to format text lines (translating double asterisks into bold blocks, bullets into nice rows)
  const formatText = (text: string) => {
    return text.split("\n").map((line, i) => {
      let formattedLine = line;
      
      // Handle simple markdown headers (### or **)
      if (line.startsWith("### ")) {
        return (
          <h4 key={i} className="text-sm font-bold text-purple-950 mt-4 mb-2 first:mt-0 uppercase tracking-wider flex items-center space-x-1">
            <span>✧</span> <span>{line.replace("### ", "")}</span>
          </h4>
        );
      }
      if (line.startsWith("## ")) {
        return (
          <h3 key={i} className="text-base font-extrabold text-purple-950 mt-5 mb-3 first:mt-0 tracking-tight">
            {line.replace("## ", "")}
          </h3>
        );
      }
      
      // Bullet lists
      if (line.startsWith("* ") || line.startsWith("- ")) {
        const bulletText = line.replace(/^[\*\-]\s+/, "");
        // Bold parsing inside bullets
        return (
          <li key={i} className="ml-4 list-disc pl-1 text-xs text-gray-600 leading-relaxed my-1">
            {parseBoldText(bulletText)}
          </li>
        );
      }

      // Normal lines with potential bold asterisks
      return (
        <p key={i} className="text-xs text-gray-600 leading-relaxed my-2">
          {parseBoldText(formattedLine)}
        </p>
      );
    });
  };

  const parseBoldText = (text: string) => {
    const parts = text.split(/\*\*([^*]+)\*\*/g);
    return parts.map((part, index) => {
      // Odd indices are the matches inside **
      if (index % 2 === 1) {
        return <strong key={index} className="text-purple-950 font-bold">{part}</strong>;
      }
      return part;
    });
  };

  return (
    <section className="py-12 bg-purple-50/15" id="wellness-coach-section">
      <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8">
        
        {/* Header Block */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
          <div>
            <div className="flex items-center space-x-2">
              <span className="flex h-2 w-2 rounded-full bg-emerald-500 animate-pulse"></span>
              <span className="text-xs font-bold uppercase tracking-wider text-purple-600">Coach Holística • AI ✦</span>
            </div>
            <h2 className="font-serif text-3xl font-extrabold tracking-tight text-purple-950 mt-1">
              Consultora de Transformación Integral
            </h2>
            <p className="text-xs text-gray-500 mt-1">Pregúntale a nuestra IA sobre cuidados, rutinas, adaptógenos y salud emocional.</p>
          </div>
          
          <button
            id="reset-chat-btn"
            onClick={handleResetChat}
            className="self-start sm:self-center flex items-center space-x-1.5 rounded-full border border-purple-200 bg-white px-4 py-2 text-xs font-semibold text-purple-900 shadow-sm hover:bg-purple-50 transition-all active:scale-95"
          >
            <RefreshCw className="h-3.5 w-3.5" />
            <span>Reiniciar Consulta</span>
          </button>
        </div>

        {/* Chat Widget Container */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 bg-white rounded-3xl border border-purple-100/60 shadow-xl overflow-hidden h-[600px]">
          
          {/* Side Panel: Suggestions */}
          <div className="lg:col-span-4 border-r border-purple-100 bg-purple-50/20 p-5 flex flex-col justify-between">
            <div className="space-y-4">
              <div className="flex items-center space-x-2 text-purple-900 font-bold">
                <Sparkles className="h-4 w-4 text-purple-700 animate-pulse" />
                <span className="text-xs uppercase tracking-wider">Preguntas Frecuentes</span>
              </div>
              <p className="text-[11px] text-gray-500 leading-relaxed">
                Selecciona una de nuestras guías preestablecidas para que la Coach de MARSHOL inicie una rutina personalizada sobre tu piel, salud o bienestar.
              </p>
              
              <div className="space-y-2.5 pt-2">
                {suggestions.map((sug, idx) => (
                  <button
                    key={idx}
                    id={`sug-btn-${idx}`}
                    onClick={() => handleSendPrompt(sug.text)}
                    disabled={isLoading}
                    className="w-full text-left rounded-xl bg-white border border-purple-100 p-3 hover:border-purple-300 hover:shadow-md transition-all duration-300 active:scale-98 disabled:opacity-50"
                  >
                    <span className="block text-[10px] font-bold text-purple-700 mb-1">{sug.label}</span>
                    <span className="block text-xs text-gray-600 line-clamp-1 italic">"{sug.text}"</span>
                  </button>
                ))}
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-purple-100 space-y-2.5">
              <div className="flex items-center space-x-2 text-[10px] font-bold text-purple-950 uppercase tracking-wider">
                <Heart className="h-3.5 w-3.5 text-purple-600 fill-current" />
                <span>Alquimia Científica</span>
              </div>
              <p className="text-[10px] text-gray-500 leading-relaxed">
                Nuestras respuestas están potenciadas con Inteligencia Artificial combinando estudios clínicos de fitoterapia, adaptógenos y cosmetología consciente.
              </p>
            </div>
          </div>

          {/* Chat Conversational Box */}
          <div className="lg:col-span-8 flex flex-col h-full bg-white relative">
            
            {/* Messages Area */}
            <div className="flex-1 overflow-y-auto p-6 space-y-4 scrollbar-thin">
              {messages.map((msg) => {
                const isModel = msg.role === "model";
                return (
                  <div
                    key={msg.id}
                    className={`flex ${isModel ? "justify-start" : "justify-end"}`}
                  >
                    <div className={`flex items-start gap-3 max-w-[85%] ${!isModel && "flex-row-reverse"}`}>
                      {/* Avatar icon */}
                      <div className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-white shadow-sm ${
                        isModel ? "bg-purple-700" : "bg-purple-950"
                      }`}>
                        {isModel ? <Bot className="h-4.5 w-4.5" /> : <User className="h-4.5 w-4.5" />}
                      </div>

                      {/* Text Bubble */}
                      <div className={`rounded-2xl p-4 shadow-sm border ${
                        isModel 
                          ? "bg-purple-50/50 border-purple-100/40 text-purple-950" 
                          : "bg-purple-950 border-purple-950 text-white"
                      }`}>
                        {isModel ? (
                          <div className="space-y-1">
                            {formatText(msg.text)}
                          </div>
                        ) : (
                          <p className="text-xs leading-relaxed">{msg.text}</p>
                        )}
                        <span className={`block text-[8px] mt-1.5 ${isModel ? "text-gray-400" : "text-purple-300 text-right"}`}>
                          {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                    </div>
                  </div>
                );
              })}

              {/* Loading indicator bubble */}
              {isLoading && (
                <div className="flex justify-start">
                  <div className="flex items-start gap-3 max-w-[85%]">
                    <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-purple-700 text-white shadow-sm">
                      <Bot className="h-4.5 w-4.5 animate-bounce" />
                    </div>
                    <div className="rounded-2xl p-4 bg-purple-50/50 border border-purple-100/40 text-purple-950">
                      <div className="flex items-center space-x-2">
                        <span className="block h-2 w-2 rounded-full bg-purple-600 animate-bounce delay-100"></span>
                        <span className="block h-2 w-2 rounded-full bg-purple-600 animate-bounce delay-200"></span>
                        <span className="block h-2 w-2 rounded-full bg-purple-600 animate-bounce delay-300"></span>
                        <span className="text-xs text-purple-600 font-semibold pl-1">Canalizando energía holística...</span>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Error block */}
              {error && (
                <div className="flex items-center space-x-2 rounded-xl bg-rose-50 border border-rose-100 px-4 py-3 text-rose-700 text-xs font-semibold">
                  <AlertCircle className="h-4 w-4 shrink-0" />
                  <span>{error}</span>
                </div>
              )}
              
              <div ref={messagesEndRef} />
            </div>

            {/* Input Form Box */}
            <div className="p-4 border-t border-purple-100 bg-white">
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  handleSendPrompt(input);
                }}
                className="flex items-center gap-2"
              >
                <input
                  type="text"
                  id="chat-input-field"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  disabled={isLoading}
                  placeholder="Pregúntale a la Coach sobre piel, infusiones o rituales de calma..."
                  className="flex-1 rounded-full border border-purple-100 bg-purple-50/20 px-4 py-3 text-xs text-purple-950 outline-none focus:border-purple-300 focus:bg-white disabled:opacity-50"
                />
                
                <button
                  id="chat-submit-btn"
                  type="submit"
                  disabled={isLoading || !input.trim()}
                  className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-purple-700 text-white shadow-md hover:bg-purple-800 disabled:opacity-40 transition-all active:scale-95"
                >
                  <Send className="h-4 w-4" />
                </button>
              </form>
              <div className="flex justify-between items-center mt-2 px-1 text-[9px] text-gray-400">
                <span>Coach Activa 💜 Escribe tu duda y presiona Enter</span>
                <span>Potenciado por Gemini 3.5 Flash</span>
              </div>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
}
