import { Product, Testimonial, Habit } from "./types";

export const PRODUCTS: Product[] = [
  {
    id: "serum-amatista",
    name: "Sérum Elixir Iluminador Amatista",
    category: "skincare",
    price: 48.0,
    rating: 4.9,
    tag: "Bestseller 💜",
    description: "Sérum concentrado regenerador con bakuchiol, ácido hialurónico vegano y extracto de amatista.",
    fullDescription: "Nuestro elixir insignia revitaliza la piel a nivel celular. Combina la suavidad del bakuchiol (la alternativa natural al retinol) con la hidratación profunda del ácido hialurónico multifuncional y partículas micronizadas de amatista para reflejar un brillo instantáneo y restaurar la elasticidad perdida. Diseñado para transformar tu piel y aportar calma emocional durante tu rutina nocturna.",
    benefits: [
      "Reduce líneas de expresión y unifica el tono de la piel.",
      "Estimula la producción natural de colágeno sin causar irritación.",
      "Hidratación profunda en múltiples niveles de la epidermis.",
      "Aporta una luminosidad radiante y un efecto tensor inmediato."
    ],
    ingredients: [
      "Bakuchiol Orgánico (2%)",
      "Ácido Hialurónico Multipeso",
      "Extracto de Flor de Lavanda",
      "Micronizado de Amatista",
      "Escualano de Caña de Azúcar",
      "Extracto de Centella Asiática"
    ],
    ritual: "Aplica de 3 a 4 gotas sobre la piel limpia y ligeramente húmeda en rostro, cuello y escote. Realiza suaves movimientos ascendentes con las yemas de los dedos o con tu rodillo de cuarzo, visualizando cómo tu piel absorbe luz y vitalidad. Respira hondo su sutil aroma botánico.",
    image: "https://images.unsplash.com/photo-1608248597481-496100c80836?q=80&w=800&auto=format&fit=crop"
  },
  {
    id: "balm-purificante",
    name: "Bálsamo Limpiador Lavanda & Escualano",
    category: "skincare",
    price: 36.0,
    rating: 4.8,
    tag: "Limpieza Holística",
    description: "Bálsamo transformador de aceite a leche que remueve impurezas y calma los sentidos.",
    fullDescription: "Un bálsamo lujoso que se derrite al contacto con la piel para disolver el maquillaje, el protector solar y el exceso de sebo. Al emulsionar con agua se convierte en una leche suave que limpia profundamente sin despojar a la piel de sus aceites naturales. El aroma terapéutico de la lavanda francesa promueve un estado de paz profunda ideal para cerrar el día.",
    benefits: [
      "Limpieza profunda y purificación sin deshidratar.",
      "Elimina maquillaje a prueba de agua y contaminación ambiental.",
      "Calma rojeces y suaviza la textura de la piel sensible.",
      "Aromaterapia integrada para reducir el estrés del día."
    ],
    ingredients: [
      "Escualano Vegetal",
      "Aceite de Semilla de Jojoba",
      "Aceite Esencial de Lavanda Orgánica",
      "Extracto de Manzanilla",
      "Vitamina E (Tocoferol)"
    ],
    ritual: "Toma una pequeña cantidad con las manos secas y caliéntala entre tus palmas. Masajea sobre el rostro seco con movimientos circulares durante un minuto. Agrega un poco de agua tibia para emulsionar en una leche ligera, masajea y enjuaga completamente.",
    image: "https://images.unsplash.com/photo-1556228720-195a672e8a03?q=80&w=800&auto=format&fit=crop"
  },
  {
    id: "crema-transformacion",
    name: "Crema de Noche Transformación Celular",
    category: "skincare",
    price: 54.0,
    rating: 5.0,
    tag: "Tratamiento Intensivo",
    description: "Crema ultra-nutritiva con péptidos de cobre, ceramidas y adaptógenos botánicos.",
    fullDescription: "Una fórmula de alta gama para la fase de regeneración nocturna de la piel. Con una rica mezcla de ceramidas esenciales que reparan la barrera cutánea, péptidos de cobre que estimulan la firmeza, y extractos adaptógenos de hongos Reishi que mitigan el impacto del estrés ambiental y el cortisol en la piel. Despierta con un rostro visiblemente descansado, denso y rejuvenecido.",
    benefits: [
      "Repara activamente la barrera protectora de la piel durante la noche.",
      "Aumenta notablemente la densidad, firmeza y elasticidad cutánea.",
      "Nutre a profundidad las pieles secas, estresadas o deshidratadas.",
      "Combate los radicales libres acumulados durante el día."
    ],
    ingredients: [
      "Péptidos de Cobre",
      "Complejo de 3 Ceramidas Esenciales",
      "Extracto de Hongo Reishi (Adaptógeno)",
      "Manteca de Karité Orgánica",
      "Extracto de Semilla de Uva"
    ],
    ritual: "Como último paso de tu ritual de noche, masajea una cantidad del tamaño de un guisante sobre rostro y cuello. Presiona suavemente con tus palmas templadas para facilitar la absorción, repitiendo mentalmente: 'Mi cuerpo se regenera en paz y armonía'.",
    image: "https://images.unsplash.com/photo-1601049541289-9b1b7bbbfe19?q=80&w=800&auto=format&fit=crop"
  },
  {
    id: "elixir-violeta",
    name: "Suplemento Adaptógeno Elixir Violeta",
    category: "salud",
    price: 42.0,
    rating: 4.9,
    tag: "Nutrición Consciente",
    description: "Polvo adaptógeno purpurina con ashwagandha, reishi, arándanos y acai para la vitalidad.",
    fullDescription: "Una mezcla sinérgica de súper alimentos y adaptógenos de alta calidad para nutrir tu bienestar desde el interior. Formulado para calmar el sistema nervioso, equilibrar los niveles hormonales y proveer una poderosa dosis de antioxidantes gracias a las bayas violetas. Ideal para tomarlo en la mañana para un enfoque calmado o en la tarde para restaurar tu energía corporal.",
    benefits: [
      "Ayuda al cuerpo a adaptarse al estrés físico y mental.",
      "Combate el envejecimiento celular prematuro desde adentro.",
      "Promueve un estado de claridad mental y energía sostenida.",
      "Fortalece el sistema inmunológico y mejora la digestión holística."
    ],
    ingredients: [
      "Ashwagandha Orgánica KSM-66",
      "Extracto de Hongo Reishi de Espectro Completo",
      "Polvo de Bayas de Acai Silvestre",
      "Arándano Azul Deshidratado",
      "Polvo de Remolacha & Zanahoria Morada"
    ],
    ritual: "Disuelve una cucharadita (5g) en tu bebida favorita: leche vegetal tibia, smoothie, o agua de coco. Mézclalo bien y tómalo de manera consciente, saboreando cada sorbo como un acto de profundo amor propio y nutrición integral.",
    image: "https://images.unsplash.com/photo-1544816155-12df9643f363?q=80&w=800&auto=format&fit=crop"
  },
  {
    id: "infusion-paz",
    name: "Infusión Botánica Paz Interior",
    category: "salud",
    price: 24.0,
    rating: 4.7,
    tag: "Ritual Nocturno",
    description: "Té holístico relajante de flor de guisante de mariposa, manzanilla y lavanda.",
    fullDescription: "Una infusión mágica que deleita tanto a tus ojos como a tu espíritu. La flor Butterfly Pea (guisante de mariposa) le otorga un color azul místico natural que se transforma en un hermoso púrpura vibrante al agregarle unas gotas de limón. Combinado con flores de lavanda relajantes, manzanilla dulce y melisa para preparar a tu mente y cuerpo para un descanso verdaderamente reparador.",
    benefits: [
      "Induce una relajación muscular profunda antes de dormir.",
      "Calma la mente hiperactiva y la ansiedad nocturna.",
      "Rica en antioxidantes que combaten el daño oxidativo celular.",
      "Ofrece una experiencia sensorial de transformación visual única."
    ],
    ingredients: [
      "Flor de Guisante de Mariposa (Butterfly Pea)",
      "Flores de Lavanda Francesa Orgánica",
      "Flores de Manzanilla de Grado Médico",
      "Hojas de Melisa (Toronjil)",
      "Cáscara de Naranja Dulce"
    ],
    ritual: "Vierte agua caliente a 90°C sobre una cucharada de flores. Deja reposar durante 5-7 minutos y observa cómo el agua se tiñe de un azul profundo. Añade un chorrito de limón para ver la mágica transformación a color violeta de MARSHOL. Tómatelo templado media hora antes de dormir.",
    image: "https://images.unsplash.com/photo-1576092768241-dec231879fc3?q=80&w=800&auto=format&fit=crop"
  },
  {
    id: "exfoliante-amatista",
    name: "Exfoliante Corporal Amatista Relajante",
    category: "cuidado_personal",
    price: 32.0,
    rating: 4.8,
    tag: "Renovación Corporal",
    description: "Exfoliante mineral de sales curativas, cristales de azúcar y aceites esenciales purpuras.",
    fullDescription: "Restaura la suavidad de todo tu cuerpo con este lujoso exfoliante mineral. Sus finos cristales barren con delicadeza las células muertas de la piel mientras que su infusión de aceites de almendras y manteca de cacao hidratan intensamente. Enriquecido con polvo de amatista y aceites esenciales botánicos para realizar una purificación física y energética, aliviando la fatiga.",
    benefits: [
      "Remueve suavemente las células muertas revelando piel nueva.",
      "Nutrición instantánea gracias a sus aceites botánicos ricos.",
      "Activa la microcirculación y favorece el drenaje linfático.",
      "Aporta una sensación de ligereza, purificación y renovación energética."
    ],
    ingredients: [
      "Sal Marina Fina Purificada",
      "Cristales de Azúcar Orgánico",
      "Polvo de Amatista Natural",
      "Aceite de Almendras Dulces",
      "Aceite Esencial de Ylang Ylang & Lavanda"
    ],
    ritual: "Durante tu ducha o baño, aplica una generosa cantidad sobre la piel húmeda. Realiza masajes circulares ascendentes por todo el cuerpo, prestando especial atención a zonas secas como codos y rodillas. Enjuaga con agua templada y siente la película de hidratación sedosa.",
    image: "https://images.unsplash.com/photo-1608248597481-496100c80836?q=80&w=800&auto=format&fit=crop"
  },
  {
    id: "aceite-calma",
    name: "Aceite Esencial Roll-on Alquimia de Calma",
    category: "salud",
    price: 18.0,
    rating: 4.9,
    description: "Fórmula de aromaterapia concentrada para sienes, muñecas y puntos de pulso.",
    fullDescription: "Tu refugio de paz portátil. Este práctico roll-on contiene una concentración alquímica de aceites esenciales puros disueltos en aceite de jojoba orgánico. Diseñado para usarse en momentos de alta tensión, sobrecarga de pensamientos o antes de meditar, ayudándote a anclar tu mente en el presente y encontrar balance instantáneo.",
    benefits: [
      "Ayuda a aliviar dolores de cabeza leves por tensión y estrés.",
      "Calma la respiración agitada y estimula la tranquilidad mental.",
      "Fácil y segura aplicación directa sobre la piel en cualquier momento.",
      "Su aroma elegante y místico actúa como un perfume personal holístico."
    ],
    ingredients: [
      "Aceite de Jojoba Fraccionado",
      "Aceite Esencial de Lavandula Angustifolia",
      "Aceite de Sándalo de la India",
      "Aceite de Incienso Sacro (Boswellia)",
      "Vitamina E"
    ],
    ritual: "Aplica en sienes, muñecas, detrás de las orejas y en el centro del pecho. Frota tus muñecas, acércalas a tu rostro sin tocar los ojos, cierra los ojos y realiza 3 respiraciones profundas inhalando en 4 tiempos, reteniendo en 4 y exhalando en 6.",
    image: "https://images.unsplash.com/photo-1617897903246-719242758050?q=80&w=800&auto=format&fit=crop"
  },
  {
    id: "manteca-nectar",
    name: "Manteca Corporal Néctar de Lavanda",
    category: "cuidado_personal",
    price: 34.0,
    rating: 4.9,
    tag: "Nutrición Total",
    description: "Crema batida corporal ultra rica que repara la piel agrietada y promueve la suavidad.",
    fullDescription: "Siente un abrazo de suavidad absoluta con nuestra manteca corporal batida. Una textura densa que se absorbe mágicamente al contacto, infundiendo la piel con lípidos esenciales, vitaminas A, E y F presentes en la manteca de karité cruda de comercio justo. Perfumada naturalmente con un bouquet aromático que relaja el cuerpo para un sueño reparador.",
    benefits: [
      "Hidratación intensiva que dura hasta 48 horas continuas.",
      "Suaviza asperezas de forma duradera y previene la descamación.",
      "Mejora visiblemente la elasticidad cutánea, ideal para estiramientos.",
      "Sensación reconfortante inmediata libre de residuos grasos pesados."
    ],
    ingredients: [
      "Manteca de Karité Cruda Orgánica",
      "Manteca de Semilla de Mango",
      "Aceite de Coco Virgen Extra",
      "Extracto Botánico de Lavandula Dentata",
      "Extracto de Vainilla Real"
    ],
    ritual: "Masajea abundantemente por todo el cuerpo después del baño diario con movimientos lentos y circulares. Regálate ese tiempo para apreciar tu cuerpo y agradecer su fuerza, enfocándote en el sutil y reconfortante aroma que te envuelve.",
    image: "https://images.unsplash.com/photo-1556228720-195a672e8a03?q=80&w=800&auto=format&fit=crop"
  }
];

export const TESTIMONIALS: Testimonial[] = [
  {
    id: "1",
    name: "Camila Restrepo",
    age: 32,
    location: "Medellín, Colombia",
    text: "El Sérum Amatista cambió por completo la textura de mi piel. Antes la sentía opaca y tensa por el estrés laboral. Ahora tiene un brillo saludable que todos notan, y el olor es de otro mundo. ¡MARSHOL es mi espacio sagrado!",
    rating: 5,
    productUsed: "Sérum Elixir Iluminador Amatista",
    image: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?q=80&w=150&auto=format&fit=crop"
  },
  {
    id: "2",
    name: "Valeria Fuentes",
    age: 28,
    location: "CDMX, México",
    text: "Me encanta el enfoque de bienestar integral. Consumo el Suplemento Elixir Violeta todas las tardes en leche de almendras y he notado una reducción tremenda en mis niveles de ansiedad diaria. Duermo mucho mejor y mi digestión es otra.",
    rating: 5,
    productUsed: "Suplemento Adaptógeno Elixir Violeta",
    image: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=150&auto=format&fit=crop"
  },
  {
    id: "3",
    name: "Alejandra Gómez",
    age: 41,
    location: "Bogotá, Colombia",
    text: "Hacer el diagnóstico en la página y empezar el ritual personalizado de mañana y noche fue mi verdadera transformación. Es más que skincare, es un ritual de amor propio diario. El cambio en mi rostro y paz mental es asombroso.",
    rating: 5,
    productUsed: "Crema de Noche Transformación Celular",
    image: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?q=80&w=150&auto=format&fit=crop"
  }
];

export const DEFAULT_HABITS: Habit[] = [
  {
    id: "h1",
    name: "Limpieza Facial Doble",
    category: "skincare",
    timeOfDay: "noche",
    completed: false,
    streak: 5,
    points: 10,
    description: "Usa el bálsamo purificante para retirar impurezas oleosas, seguido de un limpiador acuoso suave."
  },
  {
    id: "h2",
    name: "Sérum Iluminador Amatista",
    category: "skincare",
    timeOfDay: "mañana",
    completed: false,
    streak: 8,
    points: 15,
    description: "Aplica de 3 a 4 gotas realizando un masaje facial ascendente para activar la luminosidad natural."
  },
  {
    id: "h3",
    name: "Toma Tu Elixir Violeta",
    category: "salud",
    timeOfDay: "mañana",
    completed: false,
    streak: 3,
    points: 10,
    description: "Mezcla una cucharadita del suplemento de adaptógenos en leche vegetal tibia o batido energético."
  },
  {
    id: "h4",
    name: "Infusión Paz Interior",
    category: "salud",
    timeOfDay: "noche",
    completed: false,
    streak: 4,
    points: 10,
    description: "Prepara tu té violeta, añade unas gotas de limón para ver la transformación, y bébelo en silencio."
  },
  {
    id: "h5",
    name: "Journaling de Transformación",
    category: "transformacion",
    timeOfDay: "noche",
    completed: false,
    streak: 6,
    points: 15,
    description: "Escribe en tu diario 3 cosas por las que agradeces hoy y una meta para tu transformación de mañana."
  },
  {
    id: "h6",
    name: "Respiración Consciente 4-4-6",
    category: "transformacion",
    timeOfDay: "mañana",
    completed: false,
    streak: 12,
    points: 10,
    description: "Dedica 3 minutos al despertar para inhalar en 4, retener en 4, y exhalar lentamente en 6."
  }
];
