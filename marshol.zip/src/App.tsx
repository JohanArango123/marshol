import { useState, useEffect } from "react";
import { Sparkles, ShoppingBag, ShieldCheck, Heart, Star, Send, ChevronRight, Check, Sparkle } from "lucide-react";

import { Product, CartItem } from "./types";
import { PRODUCTS, TESTIMONIALS } from "./data";

import Header from "./components/Header";
import Hero from "./components/Hero";
import Boutique from "./components/Boutique";
import CartDrawer from "./components/CartDrawer";
import CheckoutModal from "./components/CheckoutModal";
import WellnessCoach from "./components/WellnessCoach";
import WellnessQuiz from "./components/WellnessQuiz";
import TransformationTracker from "./components/TransformationTracker";

export default function App() {
  const [activeTab, setActiveTab] = useState<string>("home");
  const [cart, setCart] = useState<CartItem[]>(() => {
    const saved = localStorage.getItem("marshol_cart");
    return saved ? JSON.parse(saved) : [];
  });
  const [cartOpen, setCartOpen] = useState(false);
  const [quizOpen, setQuizOpen] = useState(false);
  const [checkoutOpen, setCheckoutOpen] = useState(false);
  const [initialCoachMessage, setInitialCoachMessage] = useState<string>("");

  // Persist Cart
  useEffect(() => {
    localStorage.setItem("marshol_cart", JSON.stringify(cart));
  }, [cart]);

  // Cart operations
  const handleAddToCart = (product: Product) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [...prev, { product, quantity: 1 }];
    });
  };

  const handleUpdateQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      handleRemoveItem(productId);
      return;
    }
    setCart((prev) =>
      prev.map((item) =>
        item.product.id === productId ? { ...item, quantity } : item
      )
    );
  };

  const handleRemoveItem = (productId: string) => {
    setCart((prev) => prev.filter((item) => item.product.id !== productId));
  };

  const handleClearCart = () => {
    setCart([]);
  };

  const handleOpenCoachWithProduct = (productName: string) => {
    setInitialCoachMessage(`Hola, me interesa conocer más sobre el producto "${productName}". ¿Cómo encaja en mi tipo de piel y qué rituales holísticos me sugieres para potenciar su efecto?`);
    setActiveTab("coach");
  };

  return (
    <div className="min-h-screen bg-slate-50/40 text-gray-800 flex flex-col font-sans selection:bg-purple-200 selection:text-purple-950" id="marshol-app-container">
      
      {/* Exquisite Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        cart={cart}
        setCartOpen={setCartOpen}
        openQuiz={() => setQuizOpen(true)}
      />

      {/* Main Sections */}
      <main className="flex-grow">
        {activeTab === "home" && (
          <div className="space-y-4">
            {/* Spectacular Hero Banner */}
            <Hero
              onExplore={() => setActiveTab("boutique")}
              onOpenQuiz={() => setQuizOpen(true)}
            />

            {/* Sub-section: Brand Philosophy & Pillars */}
            <section className="py-16 bg-white border-y border-purple-100/30">
              <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
                <div className="text-center max-w-3xl mx-auto mb-12">
                  <h2 className="font-serif text-3xl font-extrabold tracking-tight text-purple-950 sm:text-4xl">
                    Los Tres Pilares de tu Bienestar
                  </h2>
                  <p className="text-sm text-gray-600 mt-2">
                    Creemos que la verdadera belleza es el reflejo físico de una sintonía emocional, herbolaria y espiritual.
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                  {/* Pillar 1 */}
                  <div className="rounded-3xl border border-purple-50 bg-gradient-to-b from-purple-50/10 to-white p-6 shadow-sm hover:shadow-md transition-shadow">
                    <span className="text-3xl">🌸</span>
                    <h3 className="font-serif text-lg font-bold text-purple-950 mt-3">Skincare Alquímico</h3>
                    <p className="text-xs text-gray-500 mt-2 leading-relaxed">
                      Fórmulas botánicas puras enriquecidas con ácido hialurónico vegano, bakuchiol y micronizados de cuarzos. Actúan sobre tu epidermis hidratando profundamente y restaurando la luminosidad perdida de forma natural.
                    </p>
                  </div>

                  {/* Pillar 2 */}
                  <div className="rounded-3xl border border-purple-50 bg-gradient-to-b from-purple-50/10 to-white p-6 shadow-sm hover:shadow-md transition-shadow">
                    <span className="text-3xl">🌿</span>
                    <h3 className="font-serif text-lg font-bold text-purple-950 mt-3">Salud & Nutrición</h3>
                    <p className="text-xs text-gray-500 mt-2 leading-relaxed">
                      Adaptógenos y súper alimentos de grado terapéutico. Mezclas sinérgicas con hongo reishi, melisa y ashwagandha que nutren tu sistema hormonal, combaten el daño celular y promueven una vitalidad duradera desde adentro.
                    </p>
                  </div>

                  {/* Pillar 3 */}
                  <div className="rounded-3xl border border-purple-50 bg-gradient-to-b from-purple-50/10 to-white p-6 shadow-sm hover:shadow-md transition-shadow">
                    <span className="text-3xl">🧘</span>
                    <h3 className="font-serif text-lg font-bold text-purple-950 mt-3">Rituales de Transformación</h3>
                    <p className="text-xs text-gray-500 mt-2 leading-relaxed">
                      El bienestar integral no está completo sin una mente calma. Integramos ejercicios sencillos de mindfulness, diarios de gratitud y aromaterapia en tus rutinas cotidianas para guiar tu crecimiento personal.
                    </p>
                  </div>
                </div>
              </div>
            </section>

            {/* Sub-section: Featured Boutique Previews */}
            <section className="py-16 bg-purple-50/10">
              <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
                <div className="flex flex-col sm:flex-row justify-between items-center mb-10 gap-4">
                  <div>
                    <span className="text-xs font-bold uppercase tracking-widest text-purple-600">SELECCIÓN CONSCIENTE</span>
                    <h2 className="font-serif text-2xl font-extrabold text-purple-950 mt-0.5">Nuestros Elixires Más Buscados</h2>
                  </div>
                  <button
                    id="featured-explore-btn"
                    onClick={() => setActiveTab("boutique")}
                    className="rounded-full bg-purple-700/10 hover:bg-purple-700/15 px-6 py-2.5 text-xs font-bold text-purple-900 transition-colors flex items-center space-x-1"
                  >
                    <span>Ver toda la Boutique</span>
                    <ChevronRight className="h-4 w-4" />
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {PRODUCTS.slice(0, 3).map((product) => (
                    <div
                      key={product.id}
                      className="group relative flex flex-col overflow-hidden rounded-3xl border border-purple-50 bg-white p-3 shadow-xs hover:shadow-lg transition-all"
                    >
                      <div className="aspect-square overflow-hidden rounded-2xl bg-purple-50">
                        <img
                          src={product.image}
                          alt={product.name}
                          referrerPolicy="no-referrer"
                          className="h-full w-full object-cover transition-transform group-hover:scale-102"
                        />
                      </div>
                      <div className="pt-3 flex-1 flex flex-col justify-between">
                        <div>
                          <span className="text-[10px] font-bold text-purple-500 uppercase tracking-wide">
                            {product.category === "skincare" ? "Skincare" : "Salud"}
                          </span>
                          <h3 className="font-serif text-sm font-bold text-purple-950 mt-0.5 line-clamp-1">
                            {product.name}
                          </h3>
                          <p className="text-[11px] text-gray-500 mt-1 line-clamp-2 leading-relaxed">
                            {product.description}
                          </p>
                        </div>
                        <div className="mt-3 pt-2.5 border-t border-purple-50 flex items-center justify-between">
                          <span className="text-sm font-extrabold text-purple-950">${product.price.toFixed(2)} USD</span>
                          <button
                            id={`preview-add-to-cart-${product.id}`}
                            onClick={() => {
                              handleAddToCart(product);
                              setCartOpen(true);
                            }}
                            className="rounded-full bg-purple-50 hover:bg-purple-100 text-[10px] font-bold text-purple-950 px-3.5 py-1.5 transition-colors"
                          >
                            Agregar +
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </section>

            {/* Sub-section: Testimonials Block */}
            <section className="py-16 bg-white">
              <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
                <div className="text-center max-w-3xl mx-auto mb-12">
                  <span className="text-xs font-bold uppercase tracking-widest text-purple-600">HISTORIAS DE LUZ 💜</span>
                  <h2 className="font-serif text-3xl font-extrabold text-purple-950 sm:text-4xl mt-1">
                    Comunidad MARSHOL
                  </h2>
                  <p className="text-xs text-gray-500 mt-1">Nuestras clientes comparten su sintonía de belleza y transformación.</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {TESTIMONIALS.map((t) => (
                    <div
                      key={t.id}
                      className="rounded-3xl border border-purple-50/50 bg-purple-50/10 p-6 flex flex-col justify-between"
                    >
                      <div>
                        <div className="flex items-center space-x-1 text-yellow-500 mb-3">
                          {[...Array(t.rating)].map((_, i) => (
                            <Star key={i} className="h-3.5 w-3.5 fill-current" />
                          ))}
                        </div>
                        <p className="text-xs italic text-gray-600 leading-relaxed">
                          "{t.text}"
                        </p>
                      </div>

                      <div className="flex items-center space-x-3 mt-6 pt-4 border-t border-purple-50/50">
                        <img
                          src={t.image}
                          alt={t.name}
                          referrerPolicy="no-referrer"
                          className="h-10 w-10 rounded-full object-cover ring-2 ring-purple-100"
                        />
                        <div>
                          <h4 className="text-xs font-bold text-purple-950">{t.name}</h4>
                          <span className="block text-[10px] text-gray-500">{t.age} años • {t.location}</span>
                          <span className="block text-[8px] font-bold uppercase text-purple-600 mt-0.5">Usa: {t.productUsed}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </section>
          </div>
        )}

        {activeTab === "boutique" && (
          <Boutique
            onAddToCart={handleAddToCart}
            onOpenCoachWithProduct={handleOpenCoachWithProduct}
          />
        )}

        {activeTab === "tracker" && <TransformationTracker />}

        {activeTab === "coach" && (
          <WellnessCoach
            initialMessage={initialCoachMessage}
            clearInitialMessage={() => setInitialCoachMessage("")}
          />
        )}
      </main>

      {/* Exquisite Footer */}
      <footer className="border-t border-purple-100/50 bg-purple-950 py-12 text-white">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-10">
            
            {/* Logo, Signature monogram & slogan */}
            <div className="md:col-span-4 space-y-4">
              <div className="flex items-center space-x-3">
                {/* SVG White Monogram */}
                <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-purple-800">
                  <svg
                    viewBox="0 0 100 100"
                    className="h-7 w-7 fill-none stroke-white stroke-[6] stroke-linecap-round stroke-linejoin-round"
                  >
                    <path d="M 20 75 L 35 25 L 50 60 L 65 25 L 80 75" />
                    <path d="M 30 35 C 50 15, 70 30, 50 50 C 30 70, 50 85, 75 70" />
                  </svg>
                </div>
                <div>
                  <span className="font-serif text-xl font-bold tracking-[0.2em] text-white">
                    MARSHOL
                  </span>
                  <span className="block text-[8px] font-medium uppercase tracking-[0.15em] text-purple-300">
                    Belleza • Salud • Transformación
                  </span>
                </div>
              </div>
              <p className="text-xs text-purple-200/70 leading-relaxed">
                Nuestra misión es acompañar tu propio despertar corporal, herbolario y espiritual. Creamos fórmulas mágicas que transforman tu rutina diaria en un ritual sagrado de bienestar integral. 💜
              </p>
            </div>

            {/* Link directories */}
            <div className="md:col-span-3 space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-widest text-white">Nuestra Boutique</h4>
              <ul className="space-y-1.5 text-xs text-purple-200/75">
                <li><button onClick={() => { setActiveTab("boutique"); window.scrollTo(0, 0); }} className="hover:text-white transition-colors">Skincare Elixir Amatista</button></li>
                <li><button onClick={() => { setActiveTab("boutique"); window.scrollTo(0, 0); }} className="hover:text-white transition-colors">Adaptógenos Suplemento Violeta</button></li>
                <li><button onClick={() => { setActiveTab("boutique"); window.scrollTo(0, 0); }} className="hover:text-white transition-colors">Aromaterapia & Aceites Esenciales</button></li>
                <li><button onClick={() => { setActiveTab("boutique"); window.scrollTo(0, 0); }} className="hover:text-white transition-colors">Exfoliantes & Mantecas Corporales</button></li>
              </ul>
            </div>

            <div className="md:col-span-3 space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-widest text-white">Recursos Holísticos</h4>
              <ul className="space-y-1.5 text-xs text-purple-200/75">
                <li><button onClick={() => setQuizOpen(true)} className="hover:text-white transition-colors">Diagnóstico de Piel (IA)</button></li>
                <li><button onClick={() => { setActiveTab("coach"); window.scrollTo(0, 0); }} className="hover:text-white transition-colors">Consultar AI Coach de Bienestar</button></li>
                <li><button onClick={() => { setActiveTab("tracker"); window.scrollTo(0, 0); }} className="hover:text-white transition-colors">Mis Hábitos & Ritual Diario</button></li>
                <li><a href="#" className="hover:text-white transition-colors">Estudios de Fitoterapia Clínica</a></li>
              </ul>
            </div>

            {/* Newsletter */}
            <div className="md:col-span-2 space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-widest text-white">Sintonía MARSHOL</h4>
              <p className="text-[10px] text-purple-200/60 leading-relaxed">Suscríbete para recibir guías mensuales de herbolaria, skincare espiritual y un cupón de 10% de bienvenida.</p>
              <div className="flex rounded-xl bg-purple-900 border border-purple-800 p-1">
                <input
                  type="email"
                  placeholder="Tu email..."
                  className="flex-1 px-2.5 py-1.5 text-xs text-white bg-transparent outline-none placeholder-purple-300"
                />
                <button
                  id="newsletter-subscribe-btn"
                  onClick={() => alert("¡Gracias por sintonizar con MARSHOL! Revisa tu bandeja de entrada para recibir tu cupón.")}
                  className="rounded-lg bg-purple-700 hover:bg-purple-600 px-3 py-1.5 text-[10px] font-bold text-white transition-all active:scale-95"
                >
                  Ok
                </button>
              </div>
            </div>

          </div>

          <div className="mt-12 border-t border-purple-900 pt-6 flex flex-col sm:flex-row justify-between items-center text-[10px] text-purple-300/60 gap-4">
            <span>© 2026 MARSHOL™ Inc. Todos los derechos reservados.</span>
            <div className="flex space-x-4">
              <a href="#" className="hover:text-white transition-colors">Términos de Servicio</a>
              <a href="#" className="hover:text-white transition-colors">Política de Privacidad</a>
              <a href="#" className="hover:text-white transition-colors">Soporte Técnico</a>
            </div>
          </div>
        </div>
      </footer>

      {/* Interactive Cart sliding drawer */}
      <CartDrawer
        isOpen={cartOpen}
        onClose={() => setCartOpen(false)}
        cart={cart}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onCheckout={() => {
          setCartOpen(false);
          setCheckoutOpen(true);
        }}
      />

      {/* Interactive Diagnostic Quiz modal */}
      <WellnessQuiz
        isOpen={quizOpen}
        onClose={() => setQuizOpen(false)}
        onShowBoutique={() => {
          setActiveTab("boutique");
          setQuizOpen(false);
        }}
      />

      {/* Secure Checkout modal */}
      <CheckoutModal
        isOpen={checkoutOpen}
        onClose={() => setCheckoutOpen(false)}
        cart={cart}
        onClearCart={handleClearCart}
      />

    </div>
  );
}
